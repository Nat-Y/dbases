USE pdm_NI3;

SELECT name from parts where id IN 
	(SELECT part_child_id from part_to_part where part_parent_id IN 
		(SELECT id from parts where name = 'Qui officiis amet.'));

SELECT name from parts where id IN 
	(SELECT part_parent_id from part_to_part where part_child_id IN 
		(SELECT id from parts where name = 'Qui officiis amet.'));

WITH
tbl1 as (SELECT parts.id as lvl1_id, parts.name as lvl1_pn, part_to_part.part_child_id as lvl2_id from parts
left join part_to_part on part_to_part.part_parent_id = parts.id and parts.name = 'Qui officiis amet.'),
tbl2 as (select tbl1.*, parts.name as lvl2_pn from tbl1 
join parts on parts.id = tbl1.lvl2_id)
select * from tbl2;
	
SELECT name from parts where id IN 
	(SELECT part_id from part_to_customer where customer_id IN 
		(SELECT id from customer_comp_id where name = 'Quo ipsum dolor dolorem enim.'));
	
	
-- Vews

CREATE VIEW citizen_us AS 
	SELECT * FROM users where id IN 
		(SELECT id from citizenship_types where name = 'US')  ORDER BY last_name;


CREATE VIEW customer_users AS 
	SELECT * FROM users where id IN 
		(SELECT contact_name from customer_comp_id)  ORDER BY last_name;

-- Triggers	and functions

DROP TRIGGER IF EXISTS validate_user_access_on_insert;
DELIMITER //
CREATE TRIGGER validate_user_access_on_insert BEFORE UPDATE ON users
FOR EACH ROW BEGIN
  IF NEW.id IN (SELECT id FROM customer_users) 
  	AND NEW.permission_id != 1 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Permission should be either blank or quas, you are trying to add priviliges to customer';
  END IF;
END//		
DELIMITER ;


DROP FUNCTION IF EXISTS is_row_exists;
DELIMITER //

CREATE FUNCTION is_row_exists (target_id INT)
RETURNS BOOLEAN READS SQL DATA

BEGIN
   RETURN EXISTS(SELECT 1 FROM parts WHERE id = target_id);
 
END//

DELIMITER ;


DROP TRIGGER IF EXISTS file_to_file_validation;
DELIMITER //

CREATE TRIGGER file_to_file_validation BEFORE INSERT ON part_to_part
FOR EACH ROW BEGIN
  IF !is_row_exists(NEW.part_parent_id)
  OR !is_row_exists(NEW.part_child_id) THEN
    SIGNAL SQLSTATE "45000"
    SET MESSAGE_TEXT = "Error adding link! Target table doesn't contain row id provided!";
  END IF;
END//

DELIMITER ;
