-- MySQL dump 10.13  Distrib 5.5.62, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: pdm_NI3
-- ------------------------------------------------------
-- Server version	8.0.21-0ubuntu0.20.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Job_position_types`
--

DROP TABLE IF EXISTS `Job_position_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Job_position_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╨┤╨╛╨╗╨╢╨╜╨╛╤Б╤В╨╕',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨Ф╨╛╨╗╨╢╨╜╨╛╤Б╤В╨╕';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Job_position_types`
--

LOCK TABLES `Job_position_types` WRITE;
/*!40000 ALTER TABLE `Job_position_types` DISABLE KEYS */;
INSERT INTO `Job_position_types` VALUES (1,'error','2007-11-03 21:27:02','2003-03-28 21:35:04'),(2,'molestias','1981-08-30 02:47:08','1996-06-08 04:26:17'),(3,'quod','1987-09-26 10:18:26','1975-03-04 11:08:40'),(4,'excepturi','1980-04-30 10:50:32','1972-01-24 22:42:46'),(5,'deleniti','2002-05-08 07:11:26','1996-12-07 13:30:08');
/*!40000 ALTER TABLE `Job_position_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `citizen_us`
--

DROP TABLE IF EXISTS `citizen_us`;
/*!50001 DROP VIEW IF EXISTS `citizen_us`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `citizen_us` (
  `id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `employee_id` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `office_id` tinyint NOT NULL,
  `citizen_id` tinyint NOT NULL,
  `job_id` tinyint NOT NULL,
  `job_in_ext` tinyint NOT NULL,
  `permission_id` tinyint NOT NULL,
  `created_at` tinyint NOT NULL,
  `updated_at` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `citizenship_types`
--

DROP TABLE IF EXISTS `citizenship_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizenship_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨У╤А╨░╨╢╨┤╨░╨╜╤Б╤В╨▓╨╛ ╤Б╨╛╤В╤А╤Г╨┤╨╜╨╕╨║╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨У╤А╨░╨╢╨┤╨░╨╜╤Б╤В╨▓╨╛ ╤Б╨╛╤В╤А╤Г╨┤╨╜╨╕╨║╨░';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizenship_types`
--

LOCK TABLES `citizenship_types` WRITE;
/*!40000 ALTER TABLE `citizenship_types` DISABLE KEYS */;
INSERT INTO `citizenship_types` VALUES (1,'ur_PK','2006-08-15 09:09:20','1992-03-07 16:55:45'),(2,'es_CL','2004-02-16 01:51:30','2015-10-10 14:31:52'),(3,'ar_JO','2008-11-21 23:18:02','1973-05-24 14:04:39'),(4,'ss_ZA','2004-01-25 11:17:20','1987-10-09 11:34:56'),(5,'es_PE','2006-07-21 15:33:52','1992-10-13 14:42:53'),(6,'sh_YU','2017-07-16 05:24:02','1972-09-07 02:25:21'),(7,'hi_IN','2013-01-05 14:17:09','2001-01-30 07:14:37'),(8,'ko_KR','2016-03-06 13:11:40','1992-09-19 15:25:40'),(9,'pa_IN','1974-02-11 02:33:37','1989-11-04 12:15:19'),(10,'es_PA','2005-03-04 20:15:24','1992-09-03 07:53:33'),(11,'nds_DE','1996-06-12 04:02:38','1986-03-13 15:54:01'),(12,'nso_ZA','1978-12-04 07:42:12','1989-06-01 16:17:48'),(13,'en_AU','2004-03-22 18:24:13','1995-04-11 22:06:19'),(14,'sr_BA','1998-06-17 13:40:29','1978-06-26 17:29:20'),(15,'pt_PT','2010-05-21 18:25:19','1980-09-25 14:38:27'),(16,'hr_HR','1987-06-09 12:17:03','1983-08-17 23:13:03'),(17,'en_CA','2009-09-21 11:35:17','2006-03-16 22:26:57'),(18,'ky_KG','2006-04-24 09:09:54','2000-08-07 05:25:29'),(19,'en_IN','1975-07-22 16:57:55','2012-08-13 08:20:45'),(20,'ga_IE','1999-04-15 18:02:38','2013-03-04 22:20:25');
/*!40000 ALTER TABLE `citizenship_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор строки',
  `name` varchar(255) NOT NULL COMMENT 'страна',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Список стран';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'US','1999-06-02 09:17:36','2016-09-19 04:55:37'),(2,'UK','1999-03-07 02:54:54','1996-12-20 02:32:48'),(3,'RU','1986-11-12 19:01:06','2017-01-18 21:39:12'),(4,'GER','2018-03-08 22:21:54','1985-03-19 06:50:31'),(5,'FRA','1990-10-16 13:28:18','2001-07-21 04:58:58'),(6,'MEX','1993-01-02 18:13:39','2001-05-14 07:09:33'),(7,'IND','2014-01-19 01:01:02','1995-01-29 01:17:36');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_comp_id`
--

DROP TABLE IF EXISTS `customer_comp_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_comp_id` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╨║╨╛╨╝╨┐╨░╨╜╨╕╨╕',
  `contact_name` int unsigned NOT NULL COMMENT '╨Ъ╨╛╨╜╤В╨░╨║╤В╨╜╨╛╨╡ ╨╗╨╕╤Ж╨╛',
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨в╨╡╨╗╨╡╤Д╨╛╨╜',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Я╨╛╤З╤В╨░',
  `city` varchar(130) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨У╨╛╤А╨╛╨┤ ╨╝╨╡╤Б╤В╨╛╨╜╨░╤Е╨╛╨╢╨┤╨╡╨╜╨╕╤П',
  `country` int unsigned NOT NULL COMMENT '╨б╤В╤А╨░╨╜╨░ ╨╝╨╡╤Б╤В╨╛╨╜╨░╤Е╨╛╨╢╨┤╨╡╨╜╨╕╤П',
  `inter_contact_name` int unsigned NOT NULL COMMENT '╨Ъ╨╛╨╜╤В╨░╨║╤В╨╜╨╛╨╡ ╨╗╨╕╤Ж╨╛ ╤Б╨╛╤В╤А╤Г╨┤╨╜╨╕╨║╨░ ╨╖╨░╨┐╤А╨╛╤Б╨╕╨▓╤И╨╡╨│╨╛ ╤Б╨╛╨╖╨┤╨░╨╜╨╕╨╡ ╤Н╤В╨╛╨╣ ╨╖╨░╨┐╨╕╤Б╨╕',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `email` (`email`),
  KEY `customer_contact_name_fr` (`contact_name`),
  KEY `customer_inter_contact_name_fk` (`inter_contact_name`),
  KEY `customer_country_fk` (`country`),
  CONSTRAINT `customer_contact_name_fr` FOREIGN KEY (`contact_name`) REFERENCES `users` (`id`),
  CONSTRAINT `customer_country_fk` FOREIGN KEY (`country`) REFERENCES `country` (`id`),
  CONSTRAINT `customer_inter_contact_name_fk` FOREIGN KEY (`inter_contact_name`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨Я╤А╨╛╤Д╨╕╨╗╨╕ ╨║╨╛╨╝╨┐╨░╨╜╨╕╨╣ - ╨╖╨░╨║╨░╨╖╤З╨╕╨║╨╛╨▓';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_comp_id`
--

LOCK TABLES `customer_comp_id` WRITE;
/*!40000 ALTER TABLE `customer_comp_id` DISABLE KEYS */;
INSERT INTO `customer_comp_id` VALUES (1,'Sequi laudantium sunt omnis quam aut.',1,'(114)073-8059','laverne.balistreri@example.org','Sporerville',6,33,'1978-03-02 22:18:15','2001-01-25 03:44:22'),(2,'Sunt cumque nemo quis repellat.',20,'02315006758','mann.korbin@example.net','Flatleychester',3,9,'1971-08-16 19:25:09','2020-09-09 13:28:02'),(3,'Aspernatur eos rem ab.',39,'844-319-0425x389','kailee67@example.com','Altafort',3,24,'2011-06-26 05:07:27','2020-09-09 13:28:02'),(4,'Dicta iste alias rerum et.',12,'891.650.0048','wintheiser.jennyfer@example.net','Feliciamouth',3,11,'1976-01-25 02:03:56','2020-09-09 13:28:02'),(5,'Voluptatem ex molestiae mollitia fugit.',25,'509-424-5599x5337','turner.waino@example.org','Casperstad',3,33,'2002-07-19 17:09:19','2020-09-09 13:28:02'),(6,'Porro mollitia aliquam quam nam.',26,'1-202-310-5740','carlee.lehner@example.org','Boganchester',3,12,'1979-05-01 08:49:20','2020-09-09 13:28:02'),(7,'Omnis ducimus soluta omnis ad.',4,'118-627-3440','pouros.liam@example.org','South Angusfurt',3,10,'1991-02-21 10:52:26','2020-09-09 13:28:02'),(8,'Quo ipsum dolor dolorem enim.',37,'460-281-7749x9723','eloisa62@example.net','South Darrenhaven',3,18,'1996-02-14 11:30:46','2020-09-09 13:28:02'),(9,'Et doloremque nisi odit at aut.',35,'531-967-2459','xander.kassulke@example.net','Daijahaven',2,4,'1981-09-19 00:32:22','2014-04-04 12:28:22'),(10,'Quae laudantium aut vel dolorum sint.',24,'1-788-849-5822','craig.russel@example.org','Litzyland',3,26,'1988-10-01 13:03:18','2020-09-09 13:28:02'),(11,'Omnis tempore ipsa deleniti fugit sint.',9,'(539)211-8026x5003','trey00@example.org','West Daphney',3,7,'1993-10-07 19:57:52','2020-09-09 13:28:02'),(12,'Iste rerum quo et velit.',11,'1-432-670-4243','nils.hettinger@example.org','East Lonnieview',3,25,'1994-08-20 17:07:56','2020-09-09 13:28:02'),(13,'Unde est accusamus ut assumenda.',14,'(072)603-7699x526','jacobson.marcos@example.com','Esmeraldaview',3,38,'2019-08-26 11:29:15','2020-09-09 13:28:02'),(14,'Quo dolorem ex et tenetur omnis.',28,'220.729.6698x776','oabshire@example.org','East Shannaborough',3,31,'1986-08-31 20:05:24','2020-09-09 13:28:02'),(15,'Eligendi sint nam totam enim.',3,'018.535.7767x020','craynor@example.com','North Franco',2,15,'1977-06-05 10:09:22','1970-03-21 19:28:09');
/*!40000 ALTER TABLE `customer_comp_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `customer_users`
--

DROP TABLE IF EXISTS `customer_users`;
/*!50001 DROP VIEW IF EXISTS `customer_users`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `customer_users` (
  `id` tinyint NOT NULL,
  `first_name` tinyint NOT NULL,
  `last_name` tinyint NOT NULL,
  `employee_id` tinyint NOT NULL,
  `phone` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `office_id` tinyint NOT NULL,
  `citizen_id` tinyint NOT NULL,
  `job_id` tinyint NOT NULL,
  `job_in_ext` tinyint NOT NULL,
  `permission_id` tinyint NOT NULL,
  `created_at` tinyint NOT NULL,
  `updated_at` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `doc_to_parts`
--

DROP TABLE IF EXISTS `doc_to_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_to_parts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `part_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨┤╨╡╤В╨░╨╗╨╕',
  `doc_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  KEY `doc_to_parts_part_id_fr` (`part_id`),
  KEY `doc_to_parts_doc_id_fr` (`doc_id`),
  CONSTRAINT `doc_to_parts_doc_id_fr` FOREIGN KEY (`doc_id`) REFERENCES `documents` (`id`),
  CONSTRAINT `doc_to_parts_part_id_fr` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨░╨▒╨╗╨╕╤Ж╨░ ╤Б╨▓╤П╨╖╨╡╨╣ ╤Д╨░╨╣╨╗╨╛╨▓ ╨╕ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨╛╨▓';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doc_to_parts`
--

LOCK TABLES `doc_to_parts` WRITE;
/*!40000 ALTER TABLE `doc_to_parts` DISABLE KEYS */;
INSERT INTO `doc_to_parts` VALUES (1,1,53,'1972-04-13 19:04:18','1982-10-15 09:31:26'),(2,2,13,'2010-04-06 20:07:49','1996-03-08 10:32:56'),(3,3,50,'1998-04-07 09:45:42','2006-04-29 16:27:04'),(4,4,51,'2018-09-05 06:10:51','2017-12-01 11:05:54'),(5,5,64,'1995-06-28 22:12:25','2003-08-13 22:29:08'),(6,6,80,'2001-01-17 07:52:15','1999-03-06 10:47:06'),(7,7,86,'1974-08-21 03:05:12','1970-01-28 21:49:19'),(8,8,86,'1983-05-10 11:06:22','2012-02-09 23:48:37'),(9,9,78,'2009-07-05 22:34:45','1985-04-29 01:23:12'),(10,10,39,'2015-09-16 02:30:11','1999-11-20 23:06:37'),(11,11,19,'1991-05-09 17:55:41','1976-09-14 15:50:14'),(12,12,13,'1980-05-10 00:44:06','2008-10-01 06:21:40'),(13,13,88,'1980-08-06 11:01:30','1970-03-14 16:34:23'),(14,14,60,'1982-06-05 20:50:33','1994-06-07 14:55:16'),(15,15,25,'2010-05-24 22:17:44','1980-07-13 04:28:18'),(16,16,18,'1990-01-10 00:34:27','1998-11-08 06:31:35'),(17,17,81,'2009-01-20 00:32:15','1972-06-28 22:03:43'),(18,18,67,'1973-08-28 06:54:59','1993-07-09 05:37:15'),(19,19,57,'1981-04-29 18:31:13','2004-01-30 21:48:11'),(20,20,42,'1992-04-22 16:19:38','1987-04-06 11:26:38'),(21,21,19,'2010-07-06 01:36:18','1972-12-09 11:14:45'),(22,22,84,'2018-12-25 08:54:16','2001-01-25 02:01:45'),(23,23,32,'1998-11-25 03:21:07','1990-07-16 03:46:07'),(24,24,1,'1992-06-09 09:23:29','2007-08-04 18:55:48'),(25,25,88,'2004-03-25 07:48:59','2013-12-03 16:56:28'),(26,26,85,'1998-01-04 04:53:58','1979-01-29 16:42:51'),(27,27,66,'2013-10-28 05:13:59','2018-12-07 11:18:45'),(28,28,27,'2002-07-30 11:44:59','1973-08-27 20:24:36'),(29,29,70,'1996-11-11 07:42:38','2016-09-04 11:37:05'),(30,30,90,'2006-08-07 11:26:59','1986-05-16 17:14:10'),(31,31,18,'1993-08-09 02:04:48','2000-04-24 01:00:19'),(32,32,33,'2001-10-31 02:03:46','2016-11-21 03:18:55'),(33,33,12,'2019-12-15 04:13:45','2013-06-25 02:12:27'),(34,34,67,'2011-06-13 00:18:37','2002-01-03 18:35:59'),(35,35,84,'1993-11-26 00:29:57','2002-01-19 13:33:05'),(36,36,76,'2002-10-02 02:09:50','2000-03-17 12:28:26'),(37,37,56,'1982-11-19 17:24:19','1973-06-02 12:02:59'),(38,38,79,'1997-03-17 01:43:17','2011-07-17 00:17:27'),(39,39,72,'1976-08-30 22:46:14','1984-05-04 21:03:34'),(40,40,44,'2009-10-30 12:31:20','1988-07-09 02:41:31'),(41,41,28,'2007-07-26 07:52:10','1973-03-11 19:34:35'),(42,42,90,'1992-09-22 01:38:17','2015-02-15 10:46:38'),(43,43,56,'1981-02-11 08:20:59','2010-05-07 17:05:42'),(44,44,26,'1993-02-09 01:48:13','2017-01-19 02:04:42'),(45,45,60,'1996-08-06 04:47:26','1970-05-25 14:19:08'),(46,46,81,'2008-12-14 21:55:40','1996-10-13 04:14:44'),(47,47,43,'2017-10-18 10:51:07','1973-12-01 05:15:02'),(48,48,50,'2016-04-26 01:56:26','1981-02-26 18:38:00'),(49,49,57,'1995-09-06 12:37:02','1999-10-22 09:25:12'),(50,50,9,'2003-07-20 15:52:19','1993-02-19 08:30:46'),(51,51,2,'1988-04-24 01:41:13','1973-05-21 15:17:40'),(52,52,75,'1996-09-27 00:31:18','1998-06-27 11:25:17'),(53,53,2,'2016-11-11 02:05:53','2011-07-23 01:48:00'),(54,54,33,'1980-06-01 20:03:29','2012-02-08 20:27:22'),(55,55,75,'1979-08-31 14:10:16','1986-10-21 15:02:47'),(56,56,90,'2016-03-05 11:08:35','2006-09-14 07:41:26'),(57,57,28,'2013-11-08 11:40:51','1993-04-17 00:48:11'),(58,58,51,'2012-03-20 01:55:17','1993-08-20 20:08:20'),(59,59,27,'2009-09-29 01:55:48','2010-11-27 17:08:23'),(60,60,8,'1971-07-04 21:34:13','1973-05-13 01:41:53'),(61,61,50,'1979-12-14 00:02:28','2003-04-21 18:31:14'),(62,62,44,'2003-09-27 02:00:06','1976-02-15 05:24:45'),(63,63,40,'2011-08-01 18:56:43','1983-04-27 14:33:36'),(64,64,62,'1985-12-03 13:50:44','1970-08-24 08:04:50'),(65,65,20,'1976-10-27 14:56:34','1998-11-07 05:27:37'),(66,66,33,'1992-04-23 17:09:07','1994-08-30 06:51:39'),(67,67,47,'1971-11-25 10:22:16','2005-09-12 18:19:51'),(68,68,75,'2015-07-19 03:17:34','2016-12-21 12:44:17'),(69,69,22,'2001-05-15 23:06:17','2003-08-01 09:59:36'),(70,70,29,'1990-07-21 00:23:18','1988-03-05 15:49:38');
/*!40000 ALTER TABLE `doc_to_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doc_types`
--

DROP TABLE IF EXISTS `doc_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╤В╨╕╨┐╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨╕╨┐╤Л ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨╛╨▓';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doc_types`
--

LOCK TABLES `doc_types` WRITE;
/*!40000 ALTER TABLE `doc_types` DISABLE KEYS */;
INSERT INTO `doc_types` VALUES (1,'aut','2004-12-24 05:39:21','1985-02-25 11:39:33'),(2,'blanditiis','1995-08-25 08:26:30','2004-06-17 20:15:17'),(3,'amet','1989-01-11 14:11:47','1999-10-09 23:39:27'),(4,'explicabo','1996-03-12 03:26:24','1974-09-15 13:04:19'),(5,'non','1977-10-24 21:21:41','2019-08-14 07:15:53'),(6,'aperiam','2003-04-29 02:04:35','1976-11-13 01:06:59'),(7,'soluta','1991-10-19 19:34:34','2014-02-02 03:04:48'),(8,'repellendus','1993-05-02 23:08:54','1989-10-19 09:39:13'),(9,'omnis','2008-03-18 05:38:03','1977-10-25 22:35:58'),(10,'adipisci','1982-05-18 07:06:40','2015-01-28 07:07:09'),(11,'numquam','2019-10-18 18:39:45','1988-03-08 14:31:37'),(12,'ad','2017-04-19 09:27:36','2016-09-13 21:57:53'),(13,'velit','1985-11-21 20:15:29','1989-12-02 22:33:52'),(14,'quia','1973-02-03 17:49:58','1973-11-29 23:26:20'),(15,'cupiditate','1970-11-09 02:07:26','2003-01-16 18:02:55'),(16,'et','1996-09-11 10:20:40','1997-10-10 09:43:00'),(17,'dignissimos','1983-04-30 11:26:25','1997-04-28 14:42:40'),(18,'reiciendis','1978-11-12 23:14:37','2004-05-05 21:33:45'),(19,'delectus','1994-11-06 16:22:50','2001-11-01 18:06:46'),(20,'dolorem','1998-09-30 01:32:35','2001-06-27 17:52:32');
/*!40000 ALTER TABLE `doc_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `user_creator_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨╖╨░╨│╤А╤Г╨╖╨╕╨╗ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В',
  `user_curr_own_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨▓ ╨┤╨░╨╜╨╜╤Л╨╣ ╨╝╨╛╨╝╨╡╨╜╤В ╨╛╤В╨▓╨╡╤З╨░╨╡╤В ╨╖╨░ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В',
  `user_current_upd_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨┐╨╛╤Б╨╗╨╡╨┤╨╜╨╕╨╣ ╤А╨╡╨┤╨░╨║╤В╨╕╤А╨╛╨▓╨░╨╗ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Ш╨╝╤П ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨░',
  `descr` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Ю╨┐╨╕╤Б╨░╨╜╨╕╨╡ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨░',
  `type_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╤В╨╕╨┐ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨░',
  `lifecycle_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨╕╨╣ ╤Н╤В╨░╨┐ ╨╢╨╕╨╖╨╜╨╡╨╜╨╜╨╛╨│╨╛ ╤Ж╨╕╨║╨╗╨░ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨░',
  `revision_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨░╤П ╤А╨╡╨▓╨╕╨╖╨╕╤П ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨░',
  `is_released` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨▓╤Л╨▒╨╛╤А ╨┤╨░/╨╜╨╡╤В',
  `permission_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨╕╨╣ ╤В╨╕╨┐ ╨┤╨╛╤Б╤В╤Г╨┐╨░ ╨║ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╤Г',
  `team_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨░╤П ╨│╤А╤Г╨┐╨┐╨░ ╨┤╨╛╤Б╤В╤Г╨┐╨░ ╨║ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╤Г',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `documents_user_creator_id_fr` (`user_creator_id`),
  KEY `documents_user_curr_own_id_fr` (`user_curr_own_id`),
  KEY `documents_user_current_upd_id_fk` (`user_current_upd_id`),
  KEY `documents_doc_type_id_fk` (`type_id`),
  KEY `documents_lifecycle_id_fk` (`lifecycle_id`),
  KEY `documents_is_released_fk` (`is_released`),
  KEY `documents_permission_id_fk` (`permission_id`),
  KEY `documents_team_id_fk` (`team_id`),
  CONSTRAINT `documents_doc_type_id_fk` FOREIGN KEY (`type_id`) REFERENCES `doc_types` (`id`),
  CONSTRAINT `documents_is_released_fk` FOREIGN KEY (`is_released`) REFERENCES `is_released` (`id`),
  CONSTRAINT `documents_lifecycle_id_fk` FOREIGN KEY (`lifecycle_id`) REFERENCES `lifecycle_general` (`id`),
  CONSTRAINT `documents_permission_id_fk` FOREIGN KEY (`permission_id`) REFERENCES `permission_id` (`id`),
  CONSTRAINT `documents_team_id_fk` FOREIGN KEY (`team_id`) REFERENCES `team_id` (`id`),
  CONSTRAINT `documents_user_creator_id_fr` FOREIGN KEY (`user_creator_id`) REFERENCES `users` (`id`),
  CONSTRAINT `documents_user_curr_own_id_fr` FOREIGN KEY (`user_curr_own_id`) REFERENCES `users` (`id`),
  CONSTRAINT `documents_user_current_upd_id_fk` FOREIGN KEY (`user_current_upd_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨Ф╨╛╨║╤Г╨╝╨╡╨╜╤В╤Л';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES (1,20,12,7,'Commodi reiciendis.','Iure est cum rem soluta.',12,5,0,1,4,7,'2008-09-25 05:49:54','2020-09-09 13:19:59'),(2,5,21,35,'Corrupti minima.','Pariatur fugit dolorum dolores ipsa.',5,4,0,1,3,4,'1990-06-01 13:08:44','2020-09-09 13:19:59'),(3,11,40,33,'Quibusdam rerum.','Error corporis totam in est autem modi est.',19,12,0,1,4,6,'1986-10-23 09:11:08','2020-09-09 13:19:59'),(4,36,39,13,'Sed molestiae.','Quaerat ea maiores ab rerum eum eum voluptates.',7,5,0,1,5,1,'1976-08-11 04:43:18','2020-09-09 13:19:59'),(5,16,7,8,'Dolores nostrum.','Et rem mollitia ut ipsa fugiat.',18,7,0,1,2,4,'2020-07-18 08:34:15','2020-09-09 13:19:59'),(6,29,2,18,'Qui modi illo harum.','Et aut facilis quidem voluptas qui ducimus.',17,9,0,1,2,1,'1998-03-24 10:17:55','2020-09-09 13:19:59'),(7,32,32,25,'Velit quibusdam est.','Eligendi corporis consequatur qui.',2,12,0,1,3,1,'2012-05-27 18:03:21','2020-09-09 13:19:59'),(8,22,5,33,'Quo ipsam ipsum.','Itaque praesentium optio rem et.',9,2,0,1,1,6,'1975-09-27 00:22:53','2020-09-09 13:19:59'),(9,16,3,34,'Voluptatibus.','Aut et accusamus et eligendi.',16,4,0,1,1,5,'1995-07-07 11:43:21','2020-09-09 13:19:59'),(10,27,15,5,'Vero quo aut velit.','Sit aspernatur sint amet qui.',8,6,0,1,3,2,'2000-09-18 09:02:53','2020-09-09 13:19:59'),(11,38,35,10,'Fugiat excepturi et.','Aut molestiae neque blanditiis voluptatem.',15,10,0,1,5,6,'2008-05-15 20:50:48','2020-09-09 13:19:59'),(12,17,11,33,'Consequuntur error.','Enim soluta qui voluptates a corrupti.',20,6,0,1,4,3,'1974-09-10 02:14:03','2020-09-09 13:19:59'),(13,18,31,7,'Eligendi.','Rerum at dignissimos occaecati.',17,13,0,1,5,5,'1984-01-21 21:00:40','2020-09-09 13:19:59'),(14,3,1,11,'Dolores quo neque.','Unde rerum dolore excepturi porro quis fugiat.',15,6,0,1,2,1,'1975-04-13 07:50:16','2020-09-09 13:19:59'),(15,31,38,12,'Aut exercitationem.','Quia ad qui sint.',15,12,0,1,3,4,'2002-03-05 04:01:33','2020-09-09 13:19:59'),(16,18,15,10,'Animi illum commodi.','Sed officia et eos autem deserunt est.',17,10,0,1,1,6,'2001-06-14 19:44:53','2020-09-09 13:19:59'),(17,40,26,7,'Natus rem.','Alias delectus qui alias quas consequuntur.',9,7,0,1,2,2,'1997-08-22 14:35:18','2020-09-09 13:19:59'),(18,11,14,34,'Deleniti molestiae.','Autem iure consectetur nobis debitis.',7,6,0,1,1,1,'1992-06-19 06:05:39','2020-09-09 13:19:59'),(19,29,20,7,'Ipsum totam.','Ad sit saepe est aperiam.',10,7,0,1,3,2,'1980-08-27 02:37:01','2020-09-09 13:19:59'),(20,9,40,25,'Assumenda.','Velit tempore esse sunt tempore.',13,6,0,1,5,4,'1991-10-22 01:04:56','2020-09-09 13:19:59'),(21,39,35,11,'Nemo eveniet enim.','Id quis blanditiis consequuntur nulla.',19,8,0,1,3,3,'2020-08-12 12:26:30','2020-09-09 13:19:59'),(22,38,31,24,'Quaerat modi.','Dolorem et eos voluptatem quo est ducimus.',4,2,0,1,3,4,'2012-04-22 06:47:06','2020-09-09 13:19:59'),(23,18,22,23,'Enim voluptatem.','Cumque modi illo minus non doloremque.',4,1,0,1,4,5,'1975-06-11 23:51:14','2020-09-09 13:19:59'),(24,19,8,34,'Sunt magni ullam.','Accusantium sunt nobis dolorem aperiam.',14,3,0,1,3,3,'2003-08-31 02:36:57','2020-09-09 13:19:59'),(25,22,12,32,'Labore eaque.','Minus quo repellendus quod tempore et eum.',11,3,0,1,1,4,'2013-08-23 21:37:32','2020-09-09 13:19:59'),(26,27,20,33,'Ut ut quis nostrum.','Nemo et velit porro velit.',13,4,0,1,2,6,'1989-08-12 03:52:04','2020-09-09 13:19:59'),(27,14,34,13,'Sed iste repellat.','Quasi quibusdam vel quia beatae.',16,6,0,1,5,7,'2014-11-21 10:28:43','2020-09-09 13:19:59'),(28,17,24,25,'Assumenda rerum.','At modi deserunt eius et voluptatem culpa.',18,12,0,1,3,4,'2009-05-01 12:14:07','2020-09-09 13:19:59'),(29,39,35,36,'Impedit sunt quod.','Et deleniti dolor doloribus saepe nostrum aut.',11,3,0,1,4,1,'1975-08-30 05:18:23','2020-09-09 13:19:59'),(30,13,30,19,'Ullam in fuga sit.','Nesciunt soluta quasi in in aut aut.',20,4,0,1,2,5,'2003-12-23 20:46:03','2020-09-09 13:19:59'),(31,19,27,16,'Commodi nisi ut.','Sit vitae ut quam accusantium.',17,8,0,1,4,5,'1970-05-02 09:10:14','2020-09-09 13:19:59'),(32,35,22,22,'Porro.','Repellendus ipsa non pariatur vitae laborum.',6,3,0,1,1,2,'1987-03-04 13:37:55','2020-09-09 13:19:59'),(33,38,23,29,'Tempore explicabo.','Qui non corporis velit ut consectetur et vel et.',19,7,0,1,4,3,'2010-06-15 15:05:58','2020-09-09 13:19:59'),(34,24,12,17,'Quidem reiciendis.','Omnis ducimus consequatur est dolore.',18,1,0,1,5,7,'2004-02-29 03:34:16','2020-09-09 13:19:59'),(35,11,6,19,'Pariatur illo et.','Eveniet omnis totam corrupti earum ea esse quod.',15,12,0,1,5,4,'1990-08-12 01:26:46','2020-09-09 13:19:59'),(36,11,21,5,'Qui distinctio.','Assumenda ad vero voluptas dolorem culpa et.',3,1,0,1,4,3,'1994-07-31 20:12:52','2020-09-09 13:19:59'),(37,9,33,23,'Veniam quos et est.','Consequatur veniam ullam officiis architecto.',3,6,0,1,2,1,'2016-02-11 05:22:49','2020-09-09 13:19:59'),(38,33,36,19,'Tempore molestiae.','Maiores exercitationem consequuntur hic.',9,3,0,1,5,3,'1981-02-09 00:29:22','2020-09-09 13:19:59'),(39,9,30,7,'Praesentium tenetur.','Maxime sed laboriosam magnam perferendis.',10,14,0,1,4,2,'1975-10-12 04:17:15','2020-09-09 13:19:59'),(40,27,18,29,'Ipsa qui et.','Aperiam nihil voluptatem aut earum iusto et non.',19,15,0,1,5,1,'2011-12-14 00:04:36','2020-09-09 13:19:59'),(41,1,20,19,'Officia adipisci.','Placeat ab voluptas tempora asperiores.',5,5,0,1,1,3,'1985-01-16 17:44:27','2020-09-09 13:19:59'),(42,28,13,18,'Magnam magnam.','Voluptatem cum sunt accusamus dolores.',10,3,0,1,5,7,'2007-12-13 14:56:00','2020-09-09 13:19:59'),(43,15,31,8,'Voluptatem in eum.','Qui dolor id officia impedit est.',12,8,0,1,2,1,'1999-10-01 21:39:51','2020-09-09 13:19:59'),(44,16,40,11,'Autem non quia qui.','Minima ut minus maxime recusandae non.',1,7,0,1,5,7,'1991-09-14 01:12:27','2020-09-09 13:19:59'),(45,16,33,2,'Deserunt in enim.','Aut non aut ut enim.',9,5,0,1,3,5,'1995-04-03 10:10:55','2020-09-09 13:19:59'),(46,25,22,2,'In aliquam beatae.','Et repellat enim autem sit harum.',6,13,0,1,3,6,'1994-09-12 06:32:07','2020-09-09 13:19:59'),(47,2,15,28,'Consequuntur qui.','Tenetur sit ut similique ut neque dolorem.',9,2,0,1,5,1,'2016-08-06 22:52:58','2020-09-09 13:19:59'),(48,26,10,3,'Esse quo hic et.','Unde rerum debitis voluptatibus nulla.',1,4,0,1,2,1,'2017-02-28 00:54:32','2020-09-09 13:19:59'),(49,26,12,1,'Reiciendis autem.','Magni fuga et vel dolor.',1,2,0,1,1,4,'1977-10-26 13:56:47','2020-09-09 13:19:59'),(50,17,23,4,'Reiciendis ducimus.','Consequatur natus officiis rerum neque.',1,2,0,1,1,3,'1993-04-18 12:44:51','2020-09-09 13:19:59'),(51,39,24,5,'Quo aut voluptatem.','Odio quas veniam aut facilis illo et earum ut.',1,15,0,1,4,3,'2003-02-26 00:59:27','2020-09-09 13:19:59'),(52,3,27,17,'Dolore sunt nobis.','Asperiores voluptatum autem sunt fugit omnis.',14,14,0,1,3,5,'2005-04-18 18:51:32','2020-09-09 13:19:59'),(53,6,33,31,'Et labore earum ea.','At sequi sed repellendus aliquam qui.',16,2,0,1,4,6,'2017-12-06 23:38:33','2020-09-09 13:19:59'),(54,9,34,10,'Voluptatum fugiat.','Sint natus ipsum sint quidem quas hic.',13,7,0,1,2,5,'1983-07-31 13:11:50','2020-09-09 13:19:59'),(55,21,18,40,'Non tempora ratione.','Aut animi voluptatem et quis architecto ut.',10,1,0,1,1,4,'2006-07-27 23:15:18','2020-09-09 13:19:59'),(56,38,36,36,'Sequi aut omnis.','Enim distinctio voluptatem quisquam molestias.',1,9,0,1,2,5,'1974-06-19 00:11:53','2020-09-09 13:19:59'),(57,19,32,17,'Unde saepe sed quam.','Aut qui cum voluptatibus fugit non est.',12,9,0,1,1,3,'1972-05-13 05:39:40','2020-09-09 13:19:59'),(58,29,38,6,'Excepturi illo.','Rem amet velit corrupti enim.',19,12,0,1,2,4,'1974-03-16 01:20:52','2020-09-09 13:19:59'),(59,8,28,10,'Est quo suscipit.','Quasi quisquam sunt quo.',14,2,0,1,2,2,'1991-03-30 13:51:37','2020-09-09 13:19:59'),(60,6,13,26,'Quasi ut nihil.','Quia et vel a sit magnam distinctio.',2,4,0,1,3,1,'2008-04-26 09:48:19','2020-09-09 13:19:59'),(61,31,33,32,'Dolorem ea.','Veritatis quia quis soluta consequuntur beatae.',5,10,0,1,2,6,'1996-01-19 16:52:45','2020-09-09 13:19:59'),(62,9,16,6,'Facere dolor.','Nobis cum magnam aut tempora quos est modi.',19,5,0,1,2,6,'1990-11-15 06:00:14','2020-09-09 13:19:59'),(63,5,27,17,'Itaque quo nemo est.','Corrupti a est velit.',6,6,0,1,4,7,'1993-02-23 02:35:08','2020-09-09 13:19:59'),(64,20,35,6,'Rerum laborum non.','Molestiae omnis ab doloremque quo.',13,3,0,1,4,5,'1988-12-28 15:48:45','2020-09-09 13:19:59'),(65,16,12,32,'Laboriosam eius.','Aut officia voluptatibus a.',3,2,0,1,3,3,'2003-06-13 11:14:40','2020-09-09 13:19:59'),(66,29,32,6,'Autem beatae iste.','Occaecati laborum aliquid voluptas velit.',19,3,0,1,2,6,'2011-03-29 01:05:17','2020-09-09 13:19:59'),(67,20,24,28,'Autem ad eveniet.','Laborum est aspernatur vero est.',12,4,0,1,1,7,'1999-07-01 21:48:50','2020-09-09 13:19:59'),(68,25,30,36,'Ut doloremque eaque.','Hic quam qui ea deserunt quos magni vel aut.',2,9,0,1,1,5,'1996-04-29 01:54:25','2020-09-09 13:19:59'),(69,31,32,17,'Esse aut enim.','Omnis enim quis mollitia a.',4,2,0,1,1,2,'1996-07-14 11:43:56','2020-09-09 13:19:59'),(70,9,31,26,'Non harum eos et.','Sequi magnam et eum voluptas et illum.',19,8,0,1,4,7,'1988-05-01 21:00:56','2020-09-09 13:19:59'),(71,28,3,29,'Incidunt qui quod.','Sapiente quas ut sed asperiores dolorum sit.',4,10,0,1,3,6,'2016-05-02 16:40:28','2020-09-09 13:19:59'),(72,36,21,26,'Ut non nemo.','Vitae voluptatem pariatur aut sit.',11,4,0,1,3,5,'1989-06-26 19:46:02','2020-09-09 13:19:59'),(73,34,22,13,'Amet perspiciatis.','Quisquam omnis nihil magnam quas vitae.',13,6,0,1,4,6,'2002-08-19 03:30:42','2020-09-09 13:19:59'),(74,18,37,2,'Dolore iste natus.','Ut laudantium voluptas praesentium consequatur.',13,10,0,1,4,4,'1970-09-20 11:08:58','2020-09-09 13:19:59'),(75,8,18,18,'Dolorem voluptas.','Unde et et perferendis distinctio.',18,8,0,1,1,1,'1989-04-20 19:30:10','2020-09-09 13:19:59'),(76,6,23,32,'Aliquam.','Amet quae corrupti sed nisi nobis aspernatur.',1,2,0,1,3,4,'1997-04-20 22:25:42','2020-09-09 13:19:59'),(77,13,39,6,'Et rerum voluptatum.','Non nam quasi quisquam voluptatem.',4,8,0,1,3,6,'2017-09-28 12:54:51','2020-09-09 13:19:59'),(78,35,8,22,'Quaerat error amet.','Sint voluptatibus id inventore sequi.',6,2,0,1,3,7,'1994-10-31 18:07:32','2020-09-09 13:19:59'),(79,31,11,20,'Dignissimos.','Autem architecto unde et qui.',19,11,0,1,5,6,'2012-08-19 18:32:03','2020-09-09 13:19:59'),(80,9,3,33,'Molestias sint.','Est modi fugiat nesciunt nostrum unde.',8,10,0,1,4,3,'1983-06-29 21:11:47','2020-09-09 13:19:59'),(81,28,2,38,'Ratione ipsam nobis.','Assumenda non ducimus similique et.',1,1,0,1,1,2,'2016-09-22 10:03:53','2020-09-09 13:19:59'),(82,21,23,39,'Aut alias error.','Eligendi in a commodi optio.',8,12,0,1,3,5,'1983-10-31 20:50:10','2020-09-09 13:19:59'),(83,34,4,24,'Dolor fuga.','Repellendus unde velit iusto.',12,6,0,1,1,4,'1981-03-05 01:44:11','2020-09-09 13:19:59'),(84,4,40,14,'Tempora ut in nobis.','Et officia illum quia aut et.',6,2,0,1,1,5,'1971-07-17 13:18:18','2020-09-09 13:19:59'),(85,28,31,3,'Sapiente est nisi.','Aut adipisci aut id repudiandae.',8,13,0,1,5,3,'1971-09-09 00:06:46','2020-09-09 13:19:59'),(86,33,4,23,'Rerum modi maxime.','Soluta sint saepe et qui pariatur qui.',7,10,0,1,3,5,'1986-04-18 18:44:22','2020-09-09 13:19:59'),(87,16,1,14,'Veniam et aliquam.','Non exercitationem in aperiam.',5,2,0,1,5,6,'1987-08-08 04:15:05','2020-09-09 13:19:59'),(88,19,1,16,'Sit amet saepe.','Et dolores iste et facilis.',11,1,0,1,4,6,'2006-09-04 03:31:32','2020-09-09 13:19:59'),(89,3,35,20,'Omnis aut tenetur.','Rem qui neque et veniam.',16,10,0,1,3,2,'1973-04-07 12:21:01','2020-09-09 13:19:59'),(90,17,22,22,'Inventore cumque.','Unde neque fuga et.',5,10,0,1,1,4,'1999-03-06 10:52:53','2020-09-09 13:19:59');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `user_creator_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨╖╨░╨│╤А╤Г╨╖╨╕╨╗ ╤Д╨░╨╣╨╗',
  `user_curr_own_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨▓ ╨┤╨░╨╜╨╜╤Л╨╣ ╨╝╨╛╨╝╨╡╨╜╤В ╨╛╤В╨▓╨╡╤З╨░╨╡╤В ╨╖╨░ ╤Д╨░╨╣╨╗',
  `user_current_upd_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨┐╨╛╤Б╨╗╨╡╨┤╨╜╨╕╨╣ ╤А╨╡╨┤╨░╨║╤В╨╕╤А╨╛╨▓╨░╨╗ ╤Д╨░╨╣╨╗',
  `filename` varchar(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Ш╨╝╤П ╤Д╨░╨╣╨╗╨░',
  `filepath` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Я╤Г╤В╤М ╨║ ╤Д╨░╨╣╨╗╤Г',
  `size` int NOT NULL COMMENT '╨а╨░╨╖╨╝╨╡╤А ╤Д╨░╨╣╨╗╨░',
  `file_type_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╤В╨╕╨┐ ╤Д╨░╨╣╨╗╨░',
  `lifecycle_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨╕╨╣ ╤Н╤В╨░╨┐ ╨╢╨╕╨╖╨╜╨╡╨╜╨╜╨╛╨│╨╛ ╤Ж╨╕╨║╨╗╨░ ╤Д╨░╨╣╨╗╨░',
  `revision_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨░╤П ╤А╨╡╨▓╨╕╨╖╨╕╤П ╤Д╨░╨╣╨╗╨░',
  `is_released` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨▓╤Л╨▒╨╛╤А ╨┤╨░/╨╜╨╡╤В',
  `permission_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨╕╨╣ ╤В╨╕╨┐ ╨┤╨╛╤Б╤В╤Г╨┐╨░ ╨║ ╤Д╨░╨╣╨╗╤Г',
  `team_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨░╤П ╨│╤А╤Г╨┐╨┐╨░ ╨┤╨╛╤Б╤В╤Г╨┐╨░ ╨║ ╤Д╨░╨╣╨╗╤Г',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`),
  UNIQUE KEY `filepath` (`filepath`),
  KEY `file_user_creator_id_fr` (`user_creator_id`),
  KEY `file_user_curr_own_id_fr` (`user_curr_own_id`),
  KEY `file_user_current_upd_id_fk` (`user_current_upd_id`),
  KEY `file_file_type_id_fk` (`file_type_id`),
  KEY `file_lifecycle_id_fk` (`lifecycle_id`),
  KEY `file_is_released_fk` (`is_released`),
  KEY `file_permission_id_fk` (`permission_id`),
  KEY `file_team_id_fk` (`team_id`),
  CONSTRAINT `file_file_type_id_fk` FOREIGN KEY (`file_type_id`) REFERENCES `file_types` (`id`),
  CONSTRAINT `file_is_released_fk` FOREIGN KEY (`is_released`) REFERENCES `is_released` (`id`),
  CONSTRAINT `file_lifecycle_id_fk` FOREIGN KEY (`lifecycle_id`) REFERENCES `lifecycle_general` (`id`),
  CONSTRAINT `file_permission_id_fk` FOREIGN KEY (`permission_id`) REFERENCES `permission_id` (`id`),
  CONSTRAINT `file_team_id_fk` FOREIGN KEY (`team_id`) REFERENCES `team_id` (`id`),
  CONSTRAINT `file_user_creator_id_fr` FOREIGN KEY (`user_creator_id`) REFERENCES `users` (`id`),
  CONSTRAINT `file_user_curr_own_id_fr` FOREIGN KEY (`user_curr_own_id`) REFERENCES `users` (`id`),
  CONSTRAINT `file_user_current_upd_id_fk` FOREIGN KEY (`user_current_upd_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨д╨░╨╣╨╗╤Л';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES (1,12,37,36,'10997','facere',885741794,3,10,0,1,5,7,'1995-03-26 07:53:22','1999-12-27 23:33:40'),(2,7,39,32,'13103','error',1449,3,4,0,2,5,6,'1988-10-22 03:28:58','1995-02-26 17:48:07'),(3,39,19,5,'12746','est',596148,4,7,0,2,1,1,'1986-06-19 08:40:33','1983-04-07 03:58:26'),(4,3,37,7,'13075','dolor',2712737,6,4,0,2,2,4,'1998-05-18 00:02:38','1991-04-25 14:36:24'),(5,37,5,1,'11210','assumenda',5770,4,3,0,2,3,3,'1983-10-02 07:39:02','1985-04-10 07:40:54'),(6,38,11,29,'10521','repellendus',82,2,14,0,2,5,7,'1988-02-02 01:16:15','1977-03-26 02:17:49'),(7,6,5,17,'14186','placeat',0,4,13,0,2,3,7,'1985-05-25 21:08:57','1982-06-12 22:28:33'),(8,19,29,35,'14576','maxime',1,5,11,0,1,2,5,'1997-07-08 14:34:31','1990-03-29 13:35:40'),(9,9,10,7,'14910','fugit',54374,3,4,0,2,4,1,'1988-08-28 01:00:04','1979-03-19 14:56:20'),(10,36,17,13,'12729','commodi',37944,5,2,0,1,4,2,'1993-01-19 12:09:56','1994-02-07 14:22:23'),(11,17,6,31,'14940','similique',0,2,11,0,1,1,1,'1998-08-27 01:54:30','1976-11-14 05:00:54'),(12,40,40,34,'12400','consequatur',8727,5,2,0,1,2,3,'2001-01-14 00:00:27','2009-07-24 16:44:44'),(13,12,20,28,'10152','at',691529,3,2,0,1,4,1,'1984-10-18 05:09:10','1970-09-10 19:27:30'),(14,33,38,34,'13023','optio',626009745,6,4,0,2,1,5,'1995-01-10 12:45:54','2004-02-28 21:59:10'),(15,29,36,36,'12241','possimus',7739,3,3,0,2,3,2,'1971-10-25 05:37:12','1998-02-20 06:19:45'),(16,39,15,35,'13826','dolorum',214693,1,7,0,1,2,6,'1976-05-09 00:06:16','1989-07-05 05:02:02'),(17,28,3,10,'10971','ipsum',4,5,7,0,2,5,2,'2014-02-19 10:58:09','2002-10-22 09:26:44'),(18,33,28,8,'11439','odit',133,1,4,0,1,4,7,'1974-06-25 14:01:12','1993-12-17 18:46:15'),(19,9,24,15,'10969','blanditiis',80,3,9,0,2,3,4,'1988-05-03 17:35:38','1975-02-03 02:56:02'),(20,11,17,24,'14961','aut',9297629,5,10,0,2,3,3,'1987-11-26 18:25:18','1984-07-03 17:41:49'),(21,1,27,5,'14219','sint',56,3,8,0,2,4,3,'1984-10-12 06:44:21','2005-07-29 05:08:20'),(22,26,38,17,'13280','officia',740,6,4,0,1,5,4,'2015-12-20 20:58:34','1980-07-12 17:31:29'),(23,28,10,34,'10419','voluptatum',457397639,2,3,0,1,4,3,'1984-10-04 22:49:34','1973-10-11 11:31:33'),(24,32,16,4,'10793','cumque',88,3,6,0,2,4,3,'1971-02-27 09:31:35','1982-08-12 00:17:00'),(25,8,32,33,'11060','ab',2348124,5,12,0,2,1,3,'1992-10-27 15:34:04','2004-03-17 04:33:08'),(26,20,19,12,'11427','minima',7800852,5,9,0,1,2,2,'1978-07-19 05:24:31','2005-05-28 22:01:06'),(27,18,3,21,'14654','incidunt',994298704,4,7,0,1,5,2,'1978-03-28 15:50:52','1988-08-03 22:33:11'),(28,28,3,26,'10764','eius',43649,1,9,0,1,2,6,'1970-05-15 15:28:37','1980-06-07 12:58:50'),(29,5,9,21,'11013','molestiae',0,6,12,0,2,2,2,'1997-08-14 03:22:13','1972-10-05 09:00:06'),(30,2,23,1,'10594','iste',9,4,12,0,1,5,2,'2010-02-09 16:49:35','1996-03-31 13:03:21'),(31,13,15,30,'12793','dolores',817962,5,11,0,2,5,3,'1986-09-25 09:11:37','1974-06-24 22:00:35'),(32,31,25,17,'12130','magni',0,3,15,0,2,1,1,'1998-09-11 17:23:09','1996-09-08 14:57:46'),(33,1,26,38,'14383','numquam',151,5,4,0,1,1,2,'1970-04-18 11:04:58','1985-05-15 17:09:08'),(34,31,3,34,'14258','voluptate',1,3,5,0,2,4,5,'1999-10-18 07:03:53','1974-08-05 03:00:04'),(35,3,17,15,'10763','corrupti',802368,5,2,0,1,1,7,'1991-10-27 16:00:45','1982-11-06 01:06:17'),(36,39,21,9,'12076','dolorem',13,6,5,0,1,5,3,'1982-05-13 05:58:38','1972-02-18 15:38:21'),(37,40,38,5,'13624','eligendi',30,2,2,0,1,3,7,'1982-12-02 21:17:47','1976-08-22 05:33:38'),(38,9,11,16,'10519','maiores',460863,4,15,0,1,1,7,'1982-01-09 06:19:45','2019-01-07 03:53:34'),(39,19,21,30,'13815','modi',2,4,13,0,2,3,6,'1993-02-28 08:18:21','2008-07-18 02:47:41'),(40,14,26,31,'10523','autem',9029,4,15,0,2,5,7,'1981-09-13 16:06:15','2011-05-05 16:53:40'),(41,27,3,8,'12763','harum',764514627,5,4,0,2,4,4,'1985-01-26 05:15:13','1975-11-12 23:49:35'),(42,35,4,40,'11990','sunt',5532815,5,3,0,1,5,5,'2016-08-08 19:32:48','1998-02-14 04:01:48'),(43,26,22,6,'14491','voluptates',0,3,6,0,2,2,5,'1970-05-27 00:32:47','1984-07-16 14:49:55'),(44,9,4,14,'12657','deleniti',2,2,13,0,1,2,4,'2008-11-08 23:41:20','1998-09-04 06:13:37'),(45,16,16,13,'10625','eum',85,4,1,0,2,1,7,'2004-12-26 23:11:58','1985-09-13 14:17:31'),(46,4,2,28,'10753','ducimus',2,2,3,0,2,5,6,'2004-09-10 00:31:27','2007-06-28 03:10:27'),(47,2,39,12,'14081','non',56,3,8,0,2,1,6,'2017-09-17 16:58:10','2012-05-19 08:03:42'),(48,28,18,38,'10009','in',438,4,12,0,1,1,1,'1990-03-16 10:24:17','1996-03-24 12:01:00'),(49,22,14,30,'10785','occaecati',23482,4,5,0,2,3,3,'1994-10-30 13:22:47','1985-12-15 12:32:26'),(50,33,6,25,'13718','esse',0,6,10,0,1,4,5,'1996-12-22 02:48:41','1996-02-05 19:12:37'),(51,16,2,4,'13618','voluptatem',2670622,6,10,0,1,4,3,'2012-02-22 06:49:23','2009-11-27 10:31:37'),(52,26,24,35,'13340','doloremque',92,3,12,0,2,3,3,'2007-09-05 02:59:02','2018-02-08 18:16:45'),(53,9,11,35,'12098','qui',698,4,1,0,1,5,7,'2019-02-24 17:20:10','2014-12-09 01:09:09'),(54,18,24,34,'11832','ex',53109872,1,1,0,2,4,3,'1990-11-09 10:03:48','2004-01-05 11:15:47'),(55,27,35,13,'10737','natus',7340992,2,1,0,2,4,5,'2010-11-19 12:48:07','2015-06-13 19:34:20'),(56,23,22,4,'12907','eveniet',681106568,2,7,0,2,4,5,'2009-04-22 03:42:45','2020-06-22 12:44:24'),(57,35,19,9,'10216','quo',659105,6,12,0,1,4,2,'1983-11-08 07:03:55','1970-07-02 06:15:06'),(58,31,25,11,'12056','reprehenderit',62,5,4,0,1,1,7,'1996-07-14 14:25:39','1975-08-12 00:15:12'),(59,36,20,8,'12101','nihil',38115468,6,7,0,2,4,1,'1985-03-03 03:57:36','1998-11-17 22:58:25'),(60,16,29,14,'10386','ut',0,5,5,0,2,3,2,'2006-11-12 23:17:36','1987-08-26 06:47:05'),(61,17,28,3,'11805','et',0,1,13,0,2,2,5,'1981-05-28 23:29:13','2017-10-02 16:46:56'),(62,18,25,17,'13902','sed',27440,5,10,0,2,3,4,'2017-10-13 11:35:24','1985-08-24 04:04:13'),(63,3,31,19,'11622','repellat',2,4,10,0,1,3,1,'1983-03-23 00:13:58','1986-11-03 05:37:26'),(64,33,36,34,'12066','beatae',0,1,13,0,1,2,2,'2018-12-22 02:29:54','2004-11-19 02:46:55'),(65,1,15,16,'12414','sapiente',44,6,4,0,2,3,5,'1975-01-20 11:38:53','2001-01-28 00:23:50'),(66,14,37,14,'11460','earum',897,6,8,0,2,3,4,'1987-07-31 12:04:12','1976-10-18 08:45:07'),(67,26,38,4,'14106','provident',2,2,1,0,2,2,6,'1981-02-16 08:21:51','1987-01-15 07:18:57'),(68,22,6,39,'13493','accusamus',1555284,3,7,0,1,4,4,'2016-01-20 20:03:08','1984-10-24 22:02:11'),(69,26,40,15,'12496','accusantium',2,6,12,0,2,3,1,'1981-08-15 08:12:34','2011-05-29 15:31:54'),(70,32,34,2,'12761','asperiores',34158793,2,11,0,2,5,3,'2000-02-17 08:59:11','1980-02-04 05:44:09'),(71,19,39,26,'11103','nulla',560067,3,10,0,2,2,1,'1994-04-11 15:41:29','1988-05-21 14:04:40'),(72,3,11,21,'14963','neque',332890105,4,9,0,1,1,2,'2005-09-08 16:51:00','1991-05-26 23:55:39'),(73,5,16,2,'11376','animi',3520237,6,5,0,2,5,1,'2000-10-24 16:19:00','1999-08-02 01:48:19'),(74,16,39,15,'13710','voluptatibus',7565,1,8,0,1,3,7,'1989-07-09 21:40:01','2005-01-28 16:41:10'),(75,7,6,17,'10566','nemo',0,5,2,0,2,5,1,'2004-06-02 09:38:01','1989-05-01 11:05:35'),(76,40,17,27,'10473','voluptas',634421723,4,8,0,2,4,5,'2018-11-12 23:42:27','2008-04-01 23:02:35'),(77,2,31,19,'14900','totam',4,2,5,0,1,2,5,'2013-06-27 23:23:38','1973-09-06 05:55:00'),(78,14,30,34,'13960','deserunt',0,5,15,0,1,4,1,'1998-11-14 06:51:03','1989-10-31 05:42:24'),(79,20,7,37,'14874','expedita',98617300,4,13,0,2,4,6,'1975-01-16 03:16:01','2001-01-06 10:35:50'),(80,11,14,16,'10447','libero',8971495,5,1,0,1,3,1,'2009-03-06 04:08:51','2000-05-06 09:59:45'),(81,35,36,15,'10403','ad',66157,2,5,0,2,5,5,'2003-09-13 05:22:25','2001-08-04 03:54:19'),(82,20,29,18,'13781','doloribus',32667066,3,1,0,1,3,4,'1975-03-04 23:54:57','1974-02-08 03:05:26'),(83,15,21,4,'10125','excepturi',6955,2,6,0,2,1,5,'2013-10-24 18:35:19','1971-07-19 21:39:48'),(84,5,19,16,'11448','ipsam',138879,1,9,0,2,1,3,'1987-06-07 20:04:26','2002-11-20 03:10:54'),(85,28,22,24,'12231','vel',0,6,5,0,1,3,6,'1986-07-05 07:06:36','2001-07-29 14:17:00'),(86,9,2,10,'10835','dolore',0,2,4,0,2,4,5,'1981-03-24 21:27:10','1970-05-14 19:45:07'),(87,14,36,33,'13447','quibusdam',8,5,10,0,2,2,6,'1994-07-28 14:06:42','2014-04-09 12:59:35'),(88,14,27,35,'11706','eos',4969,6,7,0,1,2,1,'1978-09-28 14:05:35','1988-10-10 19:26:45'),(89,22,36,5,'10284','pariatur',713349,5,6,0,2,4,4,'2000-03-02 00:39:49','1993-07-07 05:35:52'),(90,30,35,34,'12821','sit',33772616,6,11,0,2,3,1,'2013-08-15 17:05:55','1990-07-03 02:37:39'),(91,21,16,30,'12083','molestias',575252729,1,5,0,1,5,5,'1995-10-24 22:09:13','1994-08-15 10:23:01'),(92,27,31,21,'11113','quisquam',291,1,12,0,2,2,3,'2005-05-01 20:22:37','1986-09-04 15:33:20'),(93,28,16,7,'13061','explicabo',825,1,2,0,2,4,6,'1971-02-09 03:15:58','1989-04-12 23:54:11'),(94,25,19,31,'14107','velit',2224,2,2,0,1,2,5,'2010-11-05 23:58:42','2015-01-04 10:56:24'),(95,29,4,31,'10564','nesciunt',493,6,2,0,2,3,6,'1987-01-06 17:34:10','2007-08-04 23:07:29'),(96,19,4,37,'10840','nobis',9589,2,14,0,1,3,5,'1975-08-05 16:04:42','2011-12-17 03:22:31'),(97,23,30,26,'11374','ea',4712614,4,8,0,1,3,1,'1975-05-07 07:56:20','2018-10-13 10:24:38'),(98,30,8,17,'14003','quas',1083,5,8,0,2,3,2,'2001-05-12 22:22:00','2015-06-27 10:04:07'),(99,35,8,9,'14820','exercitationem',496,6,14,0,2,4,3,'1976-06-19 00:40:41','1970-11-22 01:36:42'),(100,36,26,24,'13459','magnam',6234,5,13,0,1,2,3,'1971-10-03 06:08:55','1992-01-29 20:29:52');
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_to_doc`
--

DROP TABLE IF EXISTS `file_to_doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_to_doc` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `file_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╤Д╨░╨╣╨╗╨░',
  `doc_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  KEY `parts_file_id_fr` (`file_id`),
  KEY `parts_doc_id_fr` (`doc_id`),
  CONSTRAINT `parts_doc_id_fr` FOREIGN KEY (`doc_id`) REFERENCES `documents` (`id`),
  CONSTRAINT `parts_file_id_fr` FOREIGN KEY (`file_id`) REFERENCES `file` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨░╨▒╨╗╨╕╤Ж╨░ ╤Б╨▓╤П╨╖╨╡╨╣ ╤Д╨░╨╣╨╗╨╛╨▓ ╨╕ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨╛╨▓';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_to_doc`
--

LOCK TABLES `file_to_doc` WRITE;
/*!40000 ALTER TABLE `file_to_doc` DISABLE KEYS */;
INSERT INTO `file_to_doc` VALUES (1,1,51,'1978-06-06 06:30:54','1987-10-31 17:28:57'),(2,2,51,'2010-08-15 23:43:45','1981-03-13 17:17:16'),(3,3,57,'1997-09-28 22:32:10','2018-01-02 18:40:55'),(4,4,20,'2018-01-13 01:41:09','1984-12-13 16:59:11'),(5,5,18,'1973-02-17 05:22:57','2003-02-11 14:33:26'),(6,6,77,'1993-09-02 09:02:46','2012-05-09 05:30:39'),(7,7,8,'1973-12-26 23:55:39','1995-11-30 22:49:55'),(8,8,49,'2004-12-11 02:33:42','2009-01-01 08:49:19'),(9,9,46,'2020-08-19 04:38:45','2006-11-20 19:00:54'),(10,10,73,'2010-06-18 23:12:40','2013-11-23 19:31:34'),(11,11,51,'2007-09-12 11:26:37','1989-10-11 03:42:23'),(12,12,10,'2017-08-05 17:01:03','2013-10-23 12:50:32'),(13,13,3,'2002-03-06 14:47:29','2012-03-01 05:18:12'),(14,14,26,'1989-05-13 18:01:50','2007-11-20 03:39:26'),(15,15,32,'2002-04-01 15:30:33','1976-08-17 06:32:00'),(16,16,49,'2015-01-22 05:13:52','1973-05-15 08:20:40'),(17,17,33,'2002-09-09 07:38:57','1970-04-23 00:05:41'),(18,18,16,'2006-10-27 23:19:30','1989-01-29 23:34:11'),(19,19,69,'2002-04-24 00:18:57','1982-07-01 00:53:09'),(20,20,16,'2019-09-04 00:08:00','1973-01-10 03:13:19'),(21,21,71,'1973-05-12 23:26:00','2005-01-11 01:25:23'),(22,22,5,'2015-07-25 10:20:30','1984-10-03 14:44:07'),(23,23,26,'2015-06-17 06:31:13','1972-02-29 07:38:38'),(24,24,41,'2018-05-03 12:03:57','1980-07-22 07:32:07'),(25,25,23,'1975-05-27 19:19:35','1990-09-26 22:02:05'),(26,26,30,'1982-03-05 20:12:25','1979-11-04 06:51:30'),(27,27,35,'2009-08-12 01:48:39','1994-06-08 14:32:23'),(28,28,18,'2006-05-19 21:01:10','1999-03-19 00:13:12'),(29,29,60,'1988-10-29 18:09:40','1998-12-12 21:27:43'),(30,30,27,'2003-06-23 12:59:19','2012-02-05 08:05:41'),(31,31,76,'1982-09-28 19:42:36','2014-03-28 23:08:25'),(32,32,21,'1995-09-28 09:02:31','2012-09-21 06:26:50'),(33,33,78,'1992-11-13 12:01:35','1983-09-13 15:02:59'),(34,34,43,'2005-04-20 16:46:02','1989-04-26 02:48:56'),(35,35,40,'1980-05-16 05:45:01','2003-05-23 04:36:46'),(36,36,5,'2000-08-06 07:38:57','1992-09-30 20:22:41'),(37,37,30,'2015-11-28 03:28:03','1996-10-13 02:50:50'),(38,38,47,'1993-06-27 04:09:24','2006-03-08 11:46:49'),(39,39,53,'1982-11-30 22:22:17','2020-05-13 01:32:03'),(40,40,75,'1990-05-17 15:47:53','1999-12-12 03:24:36'),(41,41,30,'2009-08-27 00:33:08','1997-10-18 11:41:02'),(42,42,14,'2002-10-25 15:57:00','1998-06-08 08:47:52'),(43,43,84,'1976-03-13 21:26:00','1984-03-08 13:41:57'),(44,44,33,'2005-08-05 10:21:37','1993-01-16 07:44:34'),(45,45,39,'1980-05-31 02:20:32','1978-02-19 22:47:00'),(46,46,26,'2004-12-22 19:49:48','1991-03-07 10:45:32'),(47,47,81,'2003-07-26 08:48:34','2006-10-13 18:34:50'),(48,48,72,'1994-10-19 09:05:14','2006-02-13 09:58:53'),(49,49,42,'1973-08-13 05:41:41','2020-01-15 19:15:50'),(50,50,59,'1998-12-29 21:43:44','1999-02-26 02:10:56'),(51,51,87,'2009-05-21 23:59:54','2005-12-30 10:56:29'),(52,52,22,'2018-01-10 03:06:40','2007-09-15 08:08:46'),(53,53,63,'1997-08-21 20:29:19','1977-08-18 01:29:47'),(54,54,23,'1986-07-31 13:19:09','1991-02-17 06:51:13'),(55,55,63,'1998-01-10 03:43:11','1982-02-19 09:44:53'),(56,56,85,'2005-12-10 03:00:39','2005-10-31 01:51:12'),(57,57,53,'1980-06-20 02:10:48','1990-09-30 21:21:49'),(58,58,7,'2009-06-07 22:50:35','2008-07-25 11:59:22'),(59,59,12,'2010-06-23 15:01:30','1974-08-12 21:52:06'),(60,60,22,'2009-06-13 00:41:44','2001-06-05 09:33:31'),(61,61,34,'1986-04-07 12:32:19','1980-08-30 21:16:05'),(62,62,88,'2012-11-18 23:59:47','1987-01-29 10:28:50'),(63,63,42,'2014-10-13 02:18:39','2005-08-08 13:56:17'),(64,64,21,'1974-10-20 17:05:28','1978-07-29 09:01:39'),(65,65,41,'2010-04-13 00:24:39','2001-07-16 17:26:50'),(66,66,82,'2012-08-07 01:29:08','1985-04-02 15:36:47'),(67,67,25,'1973-01-04 10:21:47','2020-06-14 02:29:04'),(68,68,71,'2007-03-10 19:01:36','2015-11-25 17:33:43'),(69,69,38,'2013-06-27 07:39:09','2018-10-01 07:44:28'),(70,70,77,'1990-11-07 02:54:16','2020-04-17 19:01:58'),(71,71,55,'1983-04-11 07:29:19','2000-10-21 03:11:39'),(72,72,67,'1975-07-05 12:30:43','2015-02-09 21:22:46'),(73,73,90,'1979-06-10 00:28:23','1990-04-30 09:15:27'),(74,74,49,'1998-03-12 03:52:31','2009-01-20 10:24:15'),(75,75,9,'1985-01-12 20:29:28','2015-08-30 03:40:10'),(76,76,39,'1990-01-17 11:43:58','2001-10-26 01:41:53'),(77,77,75,'1996-11-18 21:46:23','1981-02-04 18:52:39'),(78,78,90,'1978-12-16 14:12:05','1989-12-02 12:31:23'),(79,79,20,'1983-07-26 23:37:21','1995-06-30 21:47:41'),(80,80,26,'1973-10-04 22:17:45','1974-04-22 17:36:08'),(81,81,58,'2004-12-26 20:45:43','2004-10-03 18:32:14'),(82,82,17,'1996-08-28 17:00:32','1970-12-31 06:29:41'),(83,83,47,'1998-03-27 00:51:47','1998-09-27 20:50:56'),(84,84,30,'1987-12-07 06:43:19','2001-11-05 12:49:00'),(85,85,39,'2015-02-09 05:05:05','2007-05-19 20:50:29'),(86,86,20,'1970-10-21 05:25:43','1999-02-19 21:00:40'),(87,87,24,'2013-08-26 22:14:56','1973-07-17 05:35:22'),(88,88,2,'2001-02-07 14:43:41','1984-09-23 12:23:11'),(89,89,27,'1974-06-09 17:13:58','1998-04-16 09:00:59'),(90,90,36,'1976-04-16 16:06:01','1995-02-17 10:50:39'),(91,91,23,'1987-04-21 01:16:59','1979-09-15 10:18:24'),(92,92,60,'2003-09-21 14:45:10','1992-09-02 18:05:09'),(93,93,34,'1984-04-28 09:12:33','2003-05-02 21:37:57'),(94,94,65,'2012-01-05 09:11:21','2018-04-08 07:10:36'),(95,95,80,'2018-02-01 07:02:59','2004-07-22 15:19:17'),(96,96,75,'1993-06-13 19:33:33','2005-01-29 21:52:19'),(97,97,57,'1984-03-08 17:57:43','1996-06-03 20:20:19'),(98,98,14,'2000-04-14 08:34:22','1991-10-12 10:18:06'),(99,99,55,'1982-01-16 10:36:37','1999-11-24 10:22:35'),(100,100,4,'2000-04-04 05:08:43','1983-02-24 20:26:06');
/*!40000 ALTER TABLE `file_to_doc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_types`
--

DROP TABLE IF EXISTS `file_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╤В╨╕╨┐╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨╕╨┐╤Л ╤Д╨░╨╣╨╗╨╛╨▓';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_types`
--

LOCK TABLES `file_types` WRITE;
/*!40000 ALTER TABLE `file_types` DISABLE KEYS */;
INSERT INTO `file_types` VALUES (1,'dicta','1983-04-18 01:57:17','1981-02-27 23:15:00'),(2,'porro','1977-05-12 19:37:38','2018-09-12 03:48:32'),(3,'quo','2008-03-27 20:46:20','1997-08-22 04:49:34'),(4,'non','2000-11-23 09:52:37','1979-05-05 06:10:13'),(5,'sed','1970-04-17 20:00:51','2020-08-28 22:06:48'),(6,'impedit','1990-01-05 23:47:33','1973-11-27 13:06:08');
/*!40000 ALTER TABLE `file_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `is_purchased`
--

DROP TABLE IF EXISTS `is_purchased`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `is_purchased` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` tinyint(1) NOT NULL COMMENT '╨Я╨╛╨║╤Г╨┐╨╜╨░╤П ╨┤╨░/╨╜╨╡╤В',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨Я╨╛╨║╤Г╨┐╨╜╨░╤П y/n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `is_purchased`
--

LOCK TABLES `is_purchased` WRITE;
/*!40000 ALTER TABLE `is_purchased` DISABLE KEYS */;
INSERT INTO `is_purchased` VALUES (1,0,'1971-12-13 12:55:50','1973-11-03 09:43:24'),(2,1,'2004-01-14 05:15:25','1995-01-29 23:41:57');
/*!40000 ALTER TABLE `is_purchased` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `is_released`
--

DROP TABLE IF EXISTS `is_released`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `is_released` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` tinyint(1) NOT NULL COMMENT '╨Ч╨░╤А╨╡╨╗╨╕╨╖╨╡╨╜ ╨┤╨░/╨╜╨╡╤В',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Released y/n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `is_released`
--

LOCK TABLES `is_released` WRITE;
/*!40000 ALTER TABLE `is_released` DISABLE KEYS */;
INSERT INTO `is_released` VALUES (1,1,'1994-11-05 16:04:35','2002-05-13 02:23:31'),(2,0,'1986-10-16 14:53:20','1986-05-22 14:35:57');
/*!40000 ALTER TABLE `is_released` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_types`
--

DROP TABLE IF EXISTS `job_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╤В╨╕╨┐╨░ ╨╖╨░╨╜╤П╤В╨╛╤Б╤В╨╕ (╨и╤В╨░╤В, ╨║╨╛╨╜╤В╤А╨░╨║╤В, ╨╖╨░╨║╨░╨╖╤З╨╕╨║)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨╕╨┐╤Л ╨╖╨░╨╜╤П╤В╨╛╤Б╤В╨╕ ╤Б╨╛╤В╤А╤Г╨┤╨╜╨╕╨║╨░ (╨и╤В╨░╤В, ╨║╨╛╨╜╤В╤А╨░╨║╤В, ╨╖╨░╨║╨░╨╖╤З╨╕╨║)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_types`
--

LOCK TABLES `job_types` WRITE;
/*!40000 ALTER TABLE `job_types` DISABLE KEYS */;
INSERT INTO `job_types` VALUES (1,'et','1987-11-12 12:49:47','1995-04-16 17:15:16'),(2,'aspernatur','1978-06-08 07:06:40','1990-01-08 23:01:54'),(3,'quos','2015-01-15 20:11:38','1996-02-09 05:56:32'),(4,'vel','2013-03-24 19:06:24','2020-06-26 07:53:28'),(5,'sunt','2014-07-22 08:24:40','2005-07-24 19:52:27'),(6,'molestias','2010-05-05 17:45:54','1971-09-03 10:29:08'),(7,'sit','1983-01-30 16:09:27','2015-11-16 01:31:39');
/*!40000 ALTER TABLE `job_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lifecycle_general`
--

DROP TABLE IF EXISTS `lifecycle_general`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lifecycle_general` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨н╤В╨░╨┐╤Л ╨Ц╨ж',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨╕╨┐╤Л lifecycle stages';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lifecycle_general`
--

LOCK TABLES `lifecycle_general` WRITE;
/*!40000 ALTER TABLE `lifecycle_general` DISABLE KEYS */;
INSERT INTO `lifecycle_general` VALUES (1,'dolor','2003-03-18 03:46:38','1984-12-18 03:46:19'),(2,'aut','2011-06-04 19:11:24','2020-07-12 23:18:31'),(3,'dolorem','2014-09-09 08:49:08','1973-04-04 03:21:27'),(4,'quaerat','1999-03-06 17:05:12','2011-08-04 05:05:58'),(5,'eaque','2007-11-27 15:44:12','2013-09-24 14:07:40'),(6,'labore','2008-09-06 23:37:24','1982-01-30 08:39:31'),(7,'quisquam','2001-04-02 15:39:17','2003-03-30 00:11:55'),(8,'et','2012-07-21 15:49:45','2000-08-01 08:25:36'),(9,'dolorum','2008-03-03 08:45:57','1994-09-04 07:54:40'),(10,'nisi','1995-11-10 00:40:45','1977-08-08 07:39:44'),(11,'autem','1991-02-08 10:35:01','2012-10-19 21:44:43'),(12,'eos','1978-11-28 19:42:30','2008-09-24 15:18:41'),(13,'quas','1977-01-09 16:40:57','1974-04-04 13:32:31'),(14,'ea','2000-06-11 08:35:38','1983-11-15 09:56:13'),(15,'illo','1980-08-15 05:42:58','1991-04-10 09:23:41');
/*!40000 ALTER TABLE `lifecycle_general` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `office_options`
--

DROP TABLE IF EXISTS `office_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `office_options` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╨╛╤Д╨╕╤Б╨░ ╤В╤А╤Г╨┤╨╛╤Г╤Б╤В╤А╨╛╨╣╤Б╤В╨▓╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨Ю╤Д╨╕╤Б ╤В╤А╤Г╨┤╨╛╤Г╤Б╤В╤А╨╛╨╣╤Б╤В╨▓╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `office_options`
--

LOCK TABLES `office_options` WRITE;
/*!40000 ALTER TABLE `office_options` DISABLE KEYS */;
INSERT INTO `office_options` VALUES (1,'New Cade','1983-12-18 17:30:54','1996-02-04 17:58:39'),(2,'Blockberg','2000-12-11 04:18:16','2000-05-26 16:28:10'),(3,'West Elna','1993-06-16 05:15:01','1995-06-04 02:52:50'),(4,'Waelchihaven','1988-03-21 04:03:53','1990-08-21 17:17:48'),(5,'Rauport','1976-06-12 16:05:44','1980-01-29 18:25:16'),(6,'West Candidomouth','2013-03-21 14:10:27','1976-01-25 18:48:39'),(7,'New Kenyattaton','2002-06-11 13:39:27','1997-05-23 08:33:44'),(8,'South Julio','1978-08-03 18:29:55','1995-10-27 02:19:13'),(9,'Goldahaven','1976-03-31 00:23:41','2005-09-20 08:17:17'),(10,'Port Howellville','1997-10-27 14:10:39','1997-07-01 06:53:17'),(11,'New Cordelltown','2010-07-19 13:37:57','1971-12-13 08:44:47'),(12,'Port Izaiah','2006-01-12 09:38:52','2017-10-12 14:12:00'),(13,'South Narcisoburgh','1998-11-13 06:43:45','1998-08-02 10:26:28'),(14,'Hansenport','1983-11-14 02:58:14','1988-09-19 10:46:09'),(15,'Boyleview','1981-07-03 09:11:09','2000-07-22 23:20:32'),(16,'Arneshire','2010-08-07 09:02:30','1996-08-19 15:30:10'),(17,'Danville','1978-02-07 17:23:19','1994-05-12 16:07:24'),(18,'Port Corine','1990-09-11 04:52:58','1975-12-07 05:38:03'),(19,'Walkerchester','2005-05-04 21:26:34','2000-01-07 01:03:22'),(20,'Doylemouth','1980-08-17 07:42:39','1989-08-10 20:50:06');
/*!40000 ALTER TABLE `office_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `part_to_customer`
--

DROP TABLE IF EXISTS `part_to_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `part_to_customer` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `customer_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨╖╨░╨║╨░╨╖╤З╨╕╨║╨░',
  `part_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨┤╨╡╤В╨░╨╗╨╕',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  KEY `part_to_customer_customer_id_fr` (`customer_id`),
  KEY `part_to_customer_part_id_fk` (`part_id`),
  CONSTRAINT `part_to_customer_customer_id_fr` FOREIGN KEY (`customer_id`) REFERENCES `customer_comp_id` (`id`),
  CONSTRAINT `part_to_customer_part_id_fk` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨░╨▒╨╗╨╕╤Ж╨░ ╤Б╨▓╤П╨╖╨╡╨╣ ╨╖╨░╨║╨░╨╖╤З╨╕╨║╨╛╨▓ ╨╕ ╨┤╨╡╤В╨░╨╗╨╡╨╣';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `part_to_customer`
--

LOCK TABLES `part_to_customer` WRITE;
/*!40000 ALTER TABLE `part_to_customer` DISABLE KEYS */;
INSERT INTO `part_to_customer` VALUES (1,3,1,'1998-01-02 08:48:11','1985-12-12 15:49:44'),(2,7,2,'1991-04-11 11:35:04','1976-03-05 22:17:53'),(3,5,3,'1983-05-09 00:47:48','2017-01-19 09:16:17'),(4,10,4,'2004-07-14 16:01:37','2002-09-14 02:49:04'),(5,7,5,'1987-02-25 03:29:28','2012-03-01 16:42:59'),(6,5,6,'2018-10-30 09:36:17','2009-12-10 17:24:46'),(7,5,7,'1975-08-17 20:34:29','1991-04-12 06:37:59'),(8,2,8,'1985-06-19 09:40:14','1999-04-26 12:42:37'),(9,1,9,'2018-08-06 09:20:35','1987-07-30 02:06:19'),(10,12,10,'2012-10-23 17:22:26','1985-08-04 02:37:53'),(11,1,11,'1996-11-12 01:01:59','1971-11-14 12:30:18'),(12,5,12,'1973-09-11 20:34:53','1993-09-05 14:12:04'),(13,3,13,'1978-03-30 22:37:45','2001-09-07 05:29:42'),(14,4,14,'1998-02-13 08:21:37','1973-07-14 00:22:43'),(15,7,15,'1983-02-12 17:02:36','1996-01-06 07:46:23'),(16,1,16,'1992-06-11 09:56:30','2006-08-11 18:01:36'),(17,12,17,'2013-02-12 12:46:00','2019-02-01 03:57:31'),(18,2,18,'1983-04-02 07:58:09','1999-09-10 13:38:12'),(19,4,19,'1980-10-06 20:30:26','1976-01-13 07:40:53'),(20,13,20,'1973-11-24 11:45:50','2003-06-09 13:35:23'),(21,4,21,'1986-01-01 07:58:42','2011-02-19 09:41:45'),(22,5,22,'2011-03-03 13:36:49','2009-05-29 06:59:42'),(23,14,23,'1997-11-25 17:40:26','1980-09-01 05:18:43'),(24,13,24,'1974-05-20 20:47:52','1989-04-05 09:22:07'),(25,12,25,'2007-02-07 07:07:21','2009-10-17 04:02:45'),(26,14,26,'1982-08-23 06:48:21','1970-02-13 21:42:01'),(27,14,27,'1992-09-12 03:18:12','2007-06-11 12:04:48'),(28,7,28,'2016-10-03 04:37:01','1972-07-15 03:02:00'),(29,9,29,'2020-06-14 13:41:08','2005-10-30 13:26:49'),(30,14,30,'1990-12-01 22:08:13','1988-02-10 22:29:19'),(31,15,31,'2006-12-14 15:32:02','2017-04-06 05:00:02'),(32,12,32,'1984-06-20 21:52:34','1977-02-21 18:48:23'),(33,6,33,'1970-06-03 06:11:20','2019-04-05 14:48:02'),(34,5,34,'1998-05-23 12:38:34','1984-12-23 01:00:36'),(35,6,35,'2004-03-03 19:48:29','1972-03-28 10:08:47'),(36,13,36,'1984-05-21 00:53:20','1987-10-17 14:18:45'),(37,10,37,'1970-08-03 13:19:56','2012-10-11 09:13:52'),(38,11,38,'1974-06-30 00:06:49','2003-10-24 22:57:08'),(39,14,39,'2010-10-01 12:26:06','1979-11-28 21:07:03'),(40,10,40,'1977-10-25 17:54:55','1997-11-29 23:19:27'),(41,7,41,'1988-05-19 03:52:52','2009-04-13 14:08:31'),(42,15,42,'2017-10-20 03:16:24','2013-01-04 04:53:59'),(43,15,43,'2019-04-16 21:33:00','1993-07-06 11:32:33'),(44,9,44,'1987-04-08 15:47:46','2006-08-23 23:10:44'),(45,4,45,'1989-10-18 15:54:17','1979-08-21 00:27:14'),(46,6,46,'1993-02-26 11:24:51','1980-06-10 08:27:18'),(47,10,47,'1981-04-15 04:13:41','1984-11-21 02:52:50'),(48,15,48,'1988-07-20 11:21:39','1979-01-19 05:05:56'),(49,8,49,'2018-11-19 21:49:41','2011-01-17 06:02:08'),(50,14,50,'2003-10-16 08:16:35','1987-03-06 02:22:40'),(51,13,51,'2014-11-30 07:19:38','1993-05-09 10:00:29'),(52,11,52,'1972-11-01 12:22:21','1987-08-28 21:09:47'),(53,3,53,'1995-08-11 18:03:18','1985-12-27 03:55:47'),(54,12,54,'1981-08-10 23:29:09','2010-02-05 13:37:51'),(55,9,55,'1977-10-09 15:21:32','2012-01-05 14:03:40'),(56,15,56,'1976-08-23 01:09:18','1990-11-17 03:39:26'),(57,11,57,'1979-03-27 13:38:23','1981-12-26 20:09:17'),(58,7,58,'1983-06-15 12:38:29','1983-01-08 05:47:40'),(59,7,59,'2004-02-09 16:45:22','2008-02-06 13:55:47'),(60,5,60,'1988-07-29 23:18:20','1979-04-10 21:23:03'),(61,6,61,'1984-08-17 20:19:42','2013-04-18 17:40:08'),(62,7,62,'2000-10-13 09:50:16','2002-01-01 12:35:55'),(63,1,63,'1979-08-22 19:07:14','2008-04-15 21:59:32'),(64,12,64,'1992-11-15 05:34:03','1992-04-11 23:46:28'),(65,11,65,'1975-03-23 10:13:32','1995-08-14 17:06:42'),(66,6,66,'1980-11-01 12:13:32','2009-08-20 23:58:49'),(67,9,67,'2008-07-03 05:37:43','2017-11-11 22:40:15'),(68,6,68,'1990-02-26 02:34:46','1998-09-16 04:54:53'),(69,1,69,'2004-12-01 10:25:13','1997-02-26 05:39:17'),(70,8,70,'1975-12-20 06:58:41','2012-12-12 23:47:51');
/*!40000 ALTER TABLE `part_to_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `part_to_part`
--

DROP TABLE IF EXISTS `part_to_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `part_to_part` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `part_parent_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨┤╨╡╤В╨░╨╗╨╕ parent',
  `part_child_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨┤╨╡╤В╨░╨╗╨╕ child',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  KEY `part_to_part_part_id_parent_fr` (`part_parent_id`),
  KEY `part_to_part_part_id_child_fr` (`part_child_id`),
  CONSTRAINT `part_to_part_part_id_child_fr` FOREIGN KEY (`part_child_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `part_to_part_part_id_parent_fr` FOREIGN KEY (`part_parent_id`) REFERENCES `parts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨░╨▒╨╗╨╕╤Ж╨░ ╤Б╨▓╤П╨╖╨╡╨╣ ╤Д╨░╨╣╨╗╨╛╨▓ ╨╕ ╨┤╨╛╨║╤Г╨╝╨╡╨╜╤В╨╛╨▓';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `part_to_part`
--

LOCK TABLES `part_to_part` WRITE;
/*!40000 ALTER TABLE `part_to_part` DISABLE KEYS */;
INSERT INTO `part_to_part` VALUES (1,35,60,'1997-11-30 18:20:52','1992-10-08 09:30:19'),(2,52,9,'2005-01-08 17:46:10','2008-11-18 13:44:34'),(3,45,11,'2016-06-10 10:49:24','2012-11-08 22:30:56'),(4,41,69,'2014-07-09 00:43:50','1996-12-01 15:29:56'),(5,13,68,'1990-11-01 02:26:30','1983-01-02 06:00:47'),(6,32,12,'1990-10-23 21:18:47','1998-05-02 22:57:31'),(7,63,16,'1995-05-05 15:06:28','1995-11-11 15:42:12'),(8,35,46,'2004-02-10 13:43:05','2002-12-10 09:03:32'),(9,40,20,'1991-05-19 08:46:36','2014-09-15 18:06:22'),(10,26,12,'1997-01-22 16:47:02','2009-10-09 18:18:15'),(11,20,19,'2016-11-18 04:50:55','2011-12-30 19:51:13'),(12,65,28,'1986-06-05 16:05:42','1999-11-13 12:43:41'),(13,36,34,'1993-11-01 00:10:58','1982-09-17 04:17:19'),(14,34,59,'1982-11-26 12:31:20','2014-12-01 03:42:21'),(15,8,6,'2001-05-12 17:07:22','2001-02-16 06:07:10'),(16,41,43,'2006-01-04 03:44:44','2020-07-31 00:21:15'),(17,65,22,'1996-09-24 09:03:26','1979-11-14 23:10:02'),(18,52,39,'1981-06-01 11:14:28','1993-08-28 20:42:06'),(19,33,22,'2003-09-30 02:42:37','2013-09-23 05:41:54'),(20,38,45,'2019-09-20 18:58:56','1983-03-13 18:22:47'),(21,19,70,'2019-09-11 17:59:54','1972-07-05 23:00:44'),(22,56,12,'1993-07-22 21:16:03','2002-06-06 15:45:06'),(23,15,21,'1981-03-12 00:02:50','1996-09-25 19:04:34'),(24,58,55,'1985-02-26 04:23:51','2004-06-18 15:49:21'),(25,41,13,'1983-03-22 01:10:24','2003-01-27 16:08:50'),(26,66,60,'2018-07-14 21:31:13','2003-11-13 20:45:25'),(27,31,61,'1993-04-09 04:34:47','2003-01-19 06:05:33'),(28,17,67,'2004-11-29 17:27:42','2000-10-13 00:13:44'),(29,25,51,'2015-02-24 14:46:51','1983-05-25 15:13:34'),(30,55,32,'2010-02-20 02:34:54','2007-06-23 15:29:54'),(31,57,25,'2018-11-28 09:18:48','1988-02-03 18:47:42'),(32,4,51,'2016-06-16 03:25:03','1974-07-26 12:27:21'),(33,46,55,'1987-04-01 16:31:44','1997-09-08 18:35:07'),(34,20,8,'2006-01-17 13:53:45','1977-06-18 05:20:24'),(35,7,58,'2012-11-06 23:25:07','1986-05-16 18:14:22'),(36,53,25,'2014-08-06 01:31:40','1985-02-10 00:59:25'),(37,57,39,'1990-11-22 03:47:14','1982-07-29 05:33:59'),(38,36,2,'2014-04-24 16:37:59','2008-01-15 00:46:20'),(39,59,23,'2004-09-30 19:45:22','2019-01-08 11:52:49'),(40,56,29,'2015-04-07 23:57:01','1984-07-18 09:08:41'),(41,36,52,'2013-07-27 17:07:20','2004-01-31 04:05:37'),(42,18,67,'1982-03-22 15:53:43','1982-07-27 09:22:57'),(43,42,35,'1974-12-21 08:14:28','2004-09-16 18:41:17'),(44,63,66,'1989-09-24 20:50:44','1975-12-05 01:30:33'),(45,16,47,'1987-11-07 07:49:30','2014-12-06 22:12:35'),(46,28,2,'2016-07-22 02:53:59','1979-12-11 20:53:00'),(47,1,32,'2000-01-14 10:06:52','2013-11-13 14:10:08'),(48,53,47,'1990-06-23 20:34:52','1973-06-26 07:23:45'),(49,16,3,'2018-11-23 07:01:22','1997-08-16 08:47:09'),(50,55,23,'2020-05-29 01:47:30','1976-11-24 09:21:42'),(51,60,37,'1988-07-19 14:08:15','1992-02-11 12:43:32'),(52,47,46,'2019-11-09 05:48:04','1980-10-04 09:09:28'),(53,5,13,'2003-06-24 09:00:29','1994-07-09 08:47:47'),(54,47,64,'1988-07-04 19:08:48','1988-09-16 05:29:43'),(55,36,33,'1978-06-15 18:05:35','2016-04-18 10:13:51'),(56,22,1,'2005-10-13 15:42:26','1990-02-28 09:11:13'),(57,14,40,'1985-03-24 19:03:07','1976-03-15 03:28:29'),(58,68,55,'2003-11-03 00:55:23','2010-04-19 20:53:49'),(59,5,60,'1988-04-16 11:22:43','2015-10-16 05:40:15'),(60,51,20,'1993-11-09 17:57:02','2002-09-04 03:49:18');
/*!40000 ALTER TABLE `part_to_part` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`natkay`@`%`*/ /*!50003 TRIGGER `file_to_file_validation` BEFORE INSERT ON `part_to_part` FOR EACH ROW BEGIN
  IF !is_row_exists(NEW.part_parent_id)
  OR !is_row_exists(NEW.part_child_id) THEN
    SIGNAL SQLSTATE "45000"
    SET MESSAGE_TEXT = "Error adding link! Target table doesn't contain row id provided!";
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `part_to_team`
--

DROP TABLE IF EXISTS `part_to_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `part_to_team` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор строки',
  `group_id` int unsigned NOT NULL COMMENT 'Ссылка на id группы',
  `part_id` int unsigned NOT NULL COMMENT 'Ссылка на id детали',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Время создания строки',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Время обновления строки',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Таблица связей групп пользователей и деталей';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `part_to_team`
--

LOCK TABLES `part_to_team` WRITE;
/*!40000 ALTER TABLE `part_to_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `part_to_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `part_types`
--

DROP TABLE IF EXISTS `part_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `part_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╤В╨╕╨┐╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨╕╨┐╤Л ╤Д╨░╨╣╨╗╨╛╨▓';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `part_types`
--

LOCK TABLES `part_types` WRITE;
/*!40000 ALTER TABLE `part_types` DISABLE KEYS */;
INSERT INTO `part_types` VALUES (1,'itaque','1988-12-29 12:37:06','1981-04-30 05:54:23'),(2,'cum','1983-11-02 03:46:42','2007-02-10 12:23:18'),(3,'et','2009-11-22 15:13:22','2020-02-25 16:20:26'),(4,'ut','2006-01-13 21:32:09','2002-05-26 16:24:16'),(5,'rerum','1983-06-05 10:00:29','2015-03-08 12:04:28'),(6,'commodi','2006-12-24 12:04:19','1984-04-13 12:51:37'),(7,'accusamus','1995-08-25 19:47:14','1991-10-19 19:55:41'),(8,'aspernatur','2006-01-30 10:28:52','1972-10-30 01:48:01'),(9,'maxime','1992-04-13 10:33:57','1997-09-15 15:57:25'),(10,'ratione','2000-01-03 16:41:40','1979-10-11 14:42:16'),(11,'aut','1971-11-21 22:53:30','2017-12-04 05:09:34'),(12,'eius','1970-12-01 08:00:58','1988-06-15 13:02:56'),(13,'reiciendis','1985-08-12 10:29:01','1986-04-13 03:13:04'),(14,'est','1993-12-01 22:01:35','1990-01-28 13:46:40'),(15,'in','2010-09-08 11:16:44','1970-02-10 11:58:16'),(16,'eaque','1975-04-10 20:15:37','1998-08-12 02:35:27'),(17,'vel','2003-05-27 09:50:25','1987-02-24 22:32:26'),(18,'eveniet','1998-12-11 22:09:47','1977-08-12 03:59:36'),(19,'sequi','2011-04-14 23:27:27','2009-09-15 22:44:12'),(20,'repudiandae','1995-02-07 09:41:19','1993-03-11 09:13:42');
/*!40000 ALTER TABLE `part_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parts`
--

DROP TABLE IF EXISTS `parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `user_creator_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╤Б╨╛╨╖╨┤╨░╨╗ ╨┤╨╡╤В╨░╨╗╤М',
  `user_curr_own_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨▓ ╨┤╨░╨╜╨╜╤Л╨╣ ╨╝╨╛╨╝╨╡╨╜╤В ╨╛╤В╨▓╨╡╤З╨░╨╡╤В ╨╖╨░ ╨┤╨╡╤В╨░╨╗╤М',
  `user_current_upd_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П, ╨║╨╛╤В╨╛╤А╤Л╨╣ ╨┐╨╛╤Б╨╗╨╡╨┤╨╜╨╕╨╣ ╤А╨╡╨┤╨░╨║╤В╨╕╤А╨╛╨▓╨░╨╗ ╨┤╨╡╤В╨░╨╗╤М',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Ш╨╝╤П ╨┤╨╡╤В╨░╨╗╨╕',
  `descr` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Ю╨┐╨╕╤Б╨░╨╜╨╕╨╡ ╨┤╨╡╤В╨░╨╗╨╕',
  `type_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╤В╨╕╨┐ ╨┤╨╡╤В╨░╨╗╨╕',
  `is_purchased` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨▓╤Л╨▒╨╛╤А ╨┐╨╛╨║╤Г╨┐╨╜╨░╤П ╨╜╨╡╤В ╨┤╨╡╤В╨░╨╗╤М',
  `lifecycle_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨╕╨╣ ╤Н╤В╨░╨┐ ╨╢╨╕╨╖╨╜╨╡╨╜╨╜╨╛╨│╨╛ ╤Ж╨╕╨║╨╗╨░ ╨┤╨╡╤В╨░╨╗╨╕',
  `revision_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨░╤П ╤А╨╡╨▓╨╕╨╖╨╕╤П ╨┤╨╡╤В╨░╨╗╨╕',
  `is_released` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ ╨▓╤Л╨▒╨╛╤А ╨┤╨░/╨╜╨╡╤В',
  `permission_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨╕╨╣ ╤В╨╕╨┐ ╨┤╨╛╤Б╤В╤Г╨┐╨░ ╨║ ╨┤╨╡╤В╨░╨╗╨╕',
  `team_id` int unsigned NOT NULL COMMENT '╨в╨╡╨║╤Г╤Й╨░╤П ╨│╤А╤Г╨┐╨┐╨░ ╨┤╨╛╤Б╤В╤Г╨┐╨░ ╨║ ╨┤╨╡╤В╨░╨╗╨╕',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parts_user_creator_id_fr` (`user_creator_id`),
  KEY `parts_user_curr_own_id_fr` (`user_curr_own_id`),
  KEY `parts_user_current_upd_id_fk` (`user_current_upd_id`),
  KEY `parts_file_type_id_fk` (`type_id`),
  KEY `parts_is_purchased_fk` (`is_purchased`),
  KEY `parts_lifecycle_id_fk` (`lifecycle_id`),
  KEY `parts_is_released_fk` (`is_released`),
  KEY `parts_permission_id_fk` (`permission_id`),
  KEY `parts_team_id_fk` (`team_id`),
  CONSTRAINT `parts_file_type_id_fk` FOREIGN KEY (`type_id`) REFERENCES `file_types` (`id`),
  CONSTRAINT `parts_is_purchased_fk` FOREIGN KEY (`is_purchased`) REFERENCES `is_purchased` (`id`),
  CONSTRAINT `parts_is_released_fk` FOREIGN KEY (`is_released`) REFERENCES `is_released` (`id`),
  CONSTRAINT `parts_lifecycle_id_fk` FOREIGN KEY (`lifecycle_id`) REFERENCES `lifecycle_general` (`id`),
  CONSTRAINT `parts_part_type_id_fk` FOREIGN KEY (`type_id`) REFERENCES `part_types` (`id`),
  CONSTRAINT `parts_permission_id_fk` FOREIGN KEY (`permission_id`) REFERENCES `permission_id` (`id`),
  CONSTRAINT `parts_team_id_fk` FOREIGN KEY (`team_id`) REFERENCES `team_id` (`id`),
  CONSTRAINT `parts_user_creator_id_fr` FOREIGN KEY (`user_creator_id`) REFERENCES `users` (`id`),
  CONSTRAINT `parts_user_curr_own_id_fr` FOREIGN KEY (`user_curr_own_id`) REFERENCES `users` (`id`),
  CONSTRAINT `parts_user_current_upd_id_fk` FOREIGN KEY (`user_current_upd_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨Ф╨╡╤В╨░╨╗╨╕';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts`
--

LOCK TABLES `parts` WRITE;
/*!40000 ALTER TABLE `parts` DISABLE KEYS */;
INSERT INTO `parts` VALUES (1,24,40,4,'Ut odio animi aut.','Minima est tenetur iure voluptatem.',2,1,14,0,2,1,3,'1982-08-06 09:21:28','2020-09-09 13:22:21'),(2,15,34,11,'Incidunt provident.','Odit enim dolor alias error omnis.',6,1,15,0,2,3,5,'1980-03-04 06:24:25','2020-09-09 13:24:49'),(3,11,17,36,'Qui sint eum beatae.','Illo temporibus id occaecati quia.',6,1,3,0,2,1,2,'1979-08-13 00:36:28','2020-09-09 13:24:49'),(4,20,27,23,'Eum qui commodi.','Aut excepturi molestias non aut neque.',6,1,4,0,1,5,6,'1986-08-03 09:36:45','2020-09-09 13:24:49'),(5,1,37,37,'Quo ratione eveniet.','Ut error est necessitatibus autem.',6,1,11,0,1,2,1,'2014-05-26 17:36:31','2020-09-09 13:24:49'),(6,35,23,17,'Nulla consequatur.','Quis delectus ad et quidem aperiam.',6,1,7,0,2,3,5,'2012-02-21 06:37:02','2020-09-09 13:24:49'),(7,14,15,19,'Consequatur quod.','Provident aut nihil nisi rerum omnis.',6,1,4,0,2,4,6,'2006-02-03 13:49:05','2020-09-09 13:24:49'),(8,8,11,11,'Consequuntur.','Sed animi dolor natus ut sit ea.',6,1,5,0,1,2,3,'1979-03-28 11:24:00','2020-09-09 13:24:49'),(9,1,7,10,'Voluptatem ipsa ut.','Quasi ut qui aut ab.',6,1,4,0,2,4,1,'1971-05-25 21:45:15','2020-09-09 13:24:49'),(10,3,9,37,'Dolores libero.','Dolore reprehenderit quasi fuga hic et.',6,1,3,0,1,1,4,'2000-04-01 20:50:16','2020-09-09 13:24:49'),(11,30,25,2,'Quo fugit quos est.','Ipsa aut velit ut ullam enim voluptas.',6,1,2,0,2,4,3,'1984-06-23 09:24:21','2020-09-09 13:24:49'),(12,40,40,30,'Et corporis natus.','Et saepe aliquam repellendus.',6,1,2,0,1,3,1,'1999-05-19 01:08:46','2020-09-09 13:22:21'),(13,7,33,32,'Voluptas nostrum in.','In odio tempore velit ullam.',6,1,6,0,2,3,3,'2001-12-20 13:38:56','2020-09-09 13:24:49'),(14,32,15,36,'Molestiae nulla.','Ut qui velit enim eius vel.',6,1,12,0,1,3,4,'1974-04-09 23:27:07','2020-09-09 13:24:49'),(15,26,20,19,'Alias mollitia.','Consequuntur sit ut iure quibusdam.',6,1,4,0,1,1,2,'2015-07-16 08:34:08','2020-09-09 13:24:49'),(16,7,34,19,'Ab sunt consectetur.','Vitae quis aut ipsam qui.',5,1,13,0,1,2,1,'1995-07-05 23:59:55','2020-09-09 13:22:21'),(17,35,4,16,'Eaque commodi sit.','Beatae ea eos autem.',4,1,11,0,2,4,4,'1978-11-12 16:12:32','2020-09-09 13:22:21'),(18,8,20,17,'Qui dolores libero.','Quam maiores quo maxime.',6,1,8,0,2,3,2,'1999-04-06 23:01:20','2020-09-09 13:24:49'),(19,15,36,38,'Quia hic molestias.','Qui minima aut sed repellendus aperiam.',6,1,2,0,1,4,2,'2010-04-04 01:48:07','2020-09-09 13:24:49'),(20,35,9,19,'Ut ut fugit id.','Necessitatibus quam sit quo quia.',6,1,4,0,2,4,1,'1977-06-12 03:33:52','2020-09-09 13:24:49'),(21,36,4,12,'Soluta dolore quis.','Adipisci quo sed dolores ut molestiae.',6,1,14,0,2,1,1,'2017-05-06 00:01:47','2020-09-09 13:24:49'),(22,16,18,2,'Doloribus inventore.','Ipsum est vero quia.',6,1,5,0,1,1,5,'2010-11-29 04:40:22','2020-09-09 13:24:49'),(23,15,2,10,'Adipisci rerum.','Voluptatem eos et et commodi.',6,1,2,0,2,4,7,'2018-03-24 09:04:05','2020-09-09 13:24:49'),(24,7,6,25,'Itaque magnam.','Voluptate repudiandae esse atque id.',6,1,14,0,1,3,6,'1991-09-13 10:03:03','2020-09-09 13:24:49'),(25,17,32,14,'Quia accusantium.','Magni omnis qui sint culpa aut.',6,1,11,0,1,3,1,'1982-09-01 04:35:55','2020-09-09 13:24:49'),(26,33,20,1,'Deleniti quibusdam.','Magni omnis quia ea enim.',3,1,15,0,1,5,3,'1997-03-30 01:14:40','2020-09-09 13:22:21'),(27,7,3,30,'Dolores est esse.','Itaque esse deleniti eius nesciunt.',5,1,1,0,1,1,2,'2009-07-03 00:49:39','2020-09-09 13:22:21'),(28,22,32,25,'Id molestias cum ex.','Earum suscipit nihil quos provident.',6,1,2,0,1,2,4,'2001-07-16 22:11:23','2020-09-09 13:24:49'),(29,37,24,35,'Voluptas ratione.','Odit corrupti cum similique eius.',6,1,15,0,1,4,6,'2005-07-13 23:00:42','2020-09-09 13:24:49'),(30,33,30,38,'Quae magnam est.','Maxime necessitatibus vel ut quos ad.',6,1,13,0,2,1,1,'1978-05-01 18:58:57','2020-09-09 13:24:49'),(31,33,34,11,'Error aliquid.','Aut eveniet autem dolorem eaque.',6,1,4,0,1,1,6,'2016-10-31 17:04:31','2020-09-09 13:24:49'),(32,9,26,10,'Voluptatem iste est.','Et voluptatem id nesciunt tempora.',6,1,12,0,1,5,5,'2017-08-07 15:29:40','2020-09-09 13:24:49'),(33,3,29,12,'Accusantium.','Architecto dolor saepe et adipisci in.',1,1,1,0,2,4,6,'2013-07-22 18:25:09','2020-09-09 13:22:21'),(34,29,30,25,'Provident dolores.','Eveniet aliquid et tenetur officia.',6,1,8,0,2,4,3,'1986-07-07 18:21:46','2020-09-09 13:24:49'),(35,22,35,6,'Necessitatibus.','Quam eaque temporibus non hic.',6,1,5,0,1,3,4,'2014-04-23 23:37:19','2020-09-09 13:24:49'),(36,32,32,33,'Assumenda soluta ea.','Ut qui eos animi soluta sint.',6,1,4,0,2,2,3,'1991-08-15 21:49:10','2020-09-09 13:24:49'),(37,15,21,14,'Ut quaerat.','Animi dolor non ullam vero et.',6,1,8,0,1,2,2,'2016-12-01 02:23:10','2020-09-09 13:24:49'),(38,35,34,32,'Necessitatibus qui.','Tempora nostrum rerum rerum.',6,1,9,0,1,4,1,'1981-07-11 18:29:31','2020-09-09 13:24:49'),(39,11,31,35,'Ratione.','Nulla consequatur debitis ut esse.',6,1,14,0,1,1,6,'2018-03-12 20:03:57','2020-09-09 13:24:49'),(40,10,35,11,'Sequi molestiae.','Nam vero ab aliquid.',6,1,8,0,1,5,7,'2009-10-06 08:37:38','2020-09-09 13:24:49'),(41,40,6,10,'Dolorum dolore quia.','Doloremque eveniet et autem dolor.',6,1,5,0,1,4,1,'2014-10-16 21:05:23','2020-09-09 13:24:49'),(42,12,20,20,'Atque commodi et.','Rem dolore voluptas iusto eveniet.',6,1,14,0,1,5,2,'1981-10-30 23:52:33','2020-09-09 13:24:49'),(43,35,32,30,'Voluptatem sint.','Quo a accusantium dolor.',6,1,4,0,2,3,4,'1997-08-15 14:48:58','2020-09-09 13:24:49'),(44,26,32,38,'Rerum et nam sed.','Enim nemo sit qui consequatur et.',4,1,5,0,2,1,2,'2005-10-21 01:56:49','2020-09-09 13:22:21'),(45,36,11,31,'Id eos qui rerum.','Possimus est quasi in et.',4,1,11,0,1,2,1,'2010-07-05 00:43:25','2020-09-09 13:22:21'),(46,39,32,35,'Velit repellat.','Totam aperiam et dolore porro.',6,1,14,0,2,1,6,'1997-02-03 23:44:27','2020-09-09 13:24:49'),(47,24,30,23,'Dolor eaque.','Repellendus culpa illo totam.',6,1,8,0,1,2,2,'1989-04-18 01:26:29','2020-09-09 13:24:49'),(48,35,9,14,'Velit.','Vero id rem vero consequuntur.',3,1,15,0,1,3,6,'1992-07-20 01:19:25','2020-09-09 13:22:21'),(49,26,8,1,'Excepturi dolorum.','Id rerum sint ab.',6,1,10,0,1,2,5,'1973-10-10 12:14:16','2020-09-09 13:24:49'),(50,4,11,19,'Soluta illo id ad.','Quam ea eos consequatur.',6,1,1,0,1,4,5,'1986-02-06 15:04:41','2020-09-09 13:24:49'),(51,9,12,18,'Non provident.','At aut pariatur sunt itaque voluptatem.',6,1,6,0,2,5,2,'1986-03-26 03:43:38','2020-09-09 13:24:49'),(52,37,9,15,'Maxime eius maxime.','Vitae maiores enim voluptates.',6,1,9,0,2,4,2,'2012-05-20 22:30:07','2020-09-09 13:24:49'),(53,39,29,23,'Accusantium iure.','Et est et quis.',6,1,1,0,2,2,1,'1975-12-05 10:28:17','2020-09-09 13:24:49'),(54,9,27,4,'Commodi delectus.','Nemo animi vel tenetur libero.',5,1,2,0,2,5,3,'1980-10-14 04:23:56','2020-09-09 13:22:21'),(55,5,13,3,'Sint nisi at facere.','Fugiat quae beatae sit.',6,1,1,0,2,4,7,'2014-03-24 16:48:41','2020-09-09 13:24:49'),(56,7,3,31,'Optio ea est velit.','Vero facere nihil quo et ut.',6,1,13,0,1,5,6,'1973-07-16 20:06:15','2020-09-09 13:24:49'),(57,8,21,16,'Ipsum eum dicta nam.','Facere minus vel facere sunt.',5,1,8,0,2,2,5,'2001-02-27 01:47:55','2020-09-09 13:22:21'),(58,11,17,38,'Qui officiis amet.','Autem et voluptatem neque.',6,1,4,0,2,4,3,'1993-12-01 19:02:35','2020-09-09 13:24:49'),(59,5,31,34,'Dolorum vel sit.','Ipsam nihil earum minus ratione et.',3,1,11,0,2,1,7,'1982-11-14 23:54:48','2020-09-09 13:22:21'),(60,25,32,26,'Nihil sint autem.','Itaque quod ex earum provident ullam.',6,1,4,0,2,2,3,'2019-02-25 12:07:47','2020-09-09 13:24:49'),(61,5,26,25,'Qui architecto.','Sint qui aliquam nihil consequatur.',6,1,4,0,2,2,4,'1997-06-17 19:12:39','2020-09-09 13:24:49'),(62,14,9,36,'Fugit et officia.','Rem amet id ex.',6,1,1,0,2,5,1,'2013-05-28 09:31:50','2020-09-09 13:24:49'),(63,16,32,10,'Fugiat quasi sunt.','Omnis alias voluptatem natus dolore ut.',3,1,6,0,1,5,7,'1993-01-16 02:59:51','2020-09-09 13:22:21'),(64,2,25,17,'Sed nihil alias.','Delectus aut rerum ut nihil error.',6,1,4,0,2,4,3,'1999-09-15 01:21:44','2020-09-09 13:22:21'),(65,12,13,38,'Atque dolorem aut.','Neque aut iusto nihil.',6,1,4,0,1,1,5,'1985-11-30 01:07:18','2020-09-09 13:24:49'),(66,17,39,8,'Commodi similique a.','Et quasi ullam illo delectus.',6,1,9,0,1,3,7,'1980-07-29 19:23:22','2020-09-09 13:24:49'),(67,38,31,3,'Amet et ut qui sed.','Alias et at minima quae eos.',6,1,1,0,1,2,1,'1986-08-31 22:09:11','2020-09-09 13:22:21'),(68,27,27,13,'Nihil minus.','Ut tempore aspernatur tempore possimus.',6,1,6,0,2,2,5,'2000-06-21 14:44:58','2020-09-09 13:24:49'),(69,13,6,8,'Nemo cum facilis.','Impedit dolorem qui vel.',6,1,6,0,1,1,6,'2015-12-14 05:49:24','2020-09-09 13:24:49'),(70,8,14,8,'Adipisci officiis.','Corrupti odio qui nihil omnis.',6,1,8,0,2,4,3,'2012-10-18 05:39:05','2020-09-09 13:24:49');
/*!40000 ALTER TABLE `parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_id`
--

DROP TABLE IF EXISTS `permission_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_id` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Э╨░╨╖╨▓╨░╨╜╨╕╨╡ ╤В╨╕╨┐╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨╕╨┐╤Л ╨┤╨╛╤Б╤В╤Г╨┐╨░';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_id`
--

LOCK TABLES `permission_id` WRITE;
/*!40000 ALTER TABLE `permission_id` DISABLE KEYS */;
INSERT INTO `permission_id` VALUES (1,'quas','2013-01-16 05:47:23','2015-06-25 17:13:03'),(2,'accusamus','2013-06-15 23:42:34','2005-02-16 12:47:03'),(3,'alias','2002-12-21 01:00:17','1977-01-30 06:12:17'),(4,'quo','1989-04-19 15:47:07','2003-09-01 08:57:55'),(5,'et','2016-01-19 11:06:06','2007-02-03 11:09:32');
/*!40000 ALTER TABLE `permission_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_id`
--

DROP TABLE IF EXISTS `team_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_id` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨У╤А╤Г╨┐╨┐╨░ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╨╡╨╣',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨░╨▒╨╗╨╕╤Ж╨░ ╨│╤А╤Г╨┐╨┐ ╨┤╨╛╤Б╤В╤Г╨┐╨░';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_id`
--

LOCK TABLES `team_id` WRITE;
/*!40000 ALTER TABLE `team_id` DISABLE KEYS */;
INSERT INTO `team_id` VALUES (1,'et','1999-06-02 09:17:36','2016-09-19 04:55:37'),(2,'tempore','1999-03-07 02:54:54','1996-12-20 02:32:48'),(3,'eos','1986-11-12 19:01:06','2017-01-18 21:39:12'),(4,'quae','2018-03-08 22:21:54','1985-03-19 06:50:31'),(5,'dolor','1990-10-16 13:28:18','2001-07-21 04:58:58'),(6,'nihil','1993-01-02 18:13:39','2001-05-14 07:09:33'),(7,'harum','2014-01-19 01:01:02','1995-01-29 01:17:36');
/*!40000 ALTER TABLE `team_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_to_user`
--

DROP TABLE IF EXISTS `team_to_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_to_user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `group_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨│╤А╤Г╨┐╨┐╤Л ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╨╡╨╣',
  `person_id` int unsigned NOT NULL COMMENT '╨б╤Б╤Л╨╗╨║╨░ ╨╜╨░ id ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  KEY `team_to_user_group_id_fr` (`group_id`),
  KEY `team_to_user_person_id_fk` (`person_id`),
  CONSTRAINT `team_to_user_group_id_fr` FOREIGN KEY (`group_id`) REFERENCES `team_id` (`id`),
  CONSTRAINT `team_to_user_person_id_fk` FOREIGN KEY (`person_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨в╨░╨▒╨╗╨╕╤Ж╨░ ╤Б╨▓╤П╨╖╨╡╨╣ ╨│╤А╤Г╨┐╨┐ ╨┤╨╛╤Б╤В╤Г╨┐╨░ ╨╕ ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╨╡╨╣';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_to_user`
--

LOCK TABLES `team_to_user` WRITE;
/*!40000 ALTER TABLE `team_to_user` DISABLE KEYS */;
INSERT INTO `team_to_user` VALUES (1,7,6,'1975-08-03 14:32:33','1973-08-12 15:57:57'),(2,2,17,'1993-10-20 06:19:37','1970-05-07 09:53:03'),(3,4,18,'1996-08-31 23:31:18','2009-06-17 20:11:31'),(4,1,39,'1981-10-07 14:15:41','2016-05-30 15:59:25'),(5,1,30,'2019-10-24 05:46:39','1984-05-31 22:21:07'),(6,2,8,'1990-05-07 19:54:55','2002-02-07 20:54:09'),(7,7,5,'1981-02-22 08:31:29','2009-01-06 19:58:54'),(8,3,24,'2000-10-04 22:18:08','1986-02-26 02:14:10'),(9,5,2,'1979-05-19 16:26:09','1991-01-18 23:17:37'),(10,3,7,'2001-01-17 06:33:21','2012-07-20 05:16:34'),(11,7,29,'1970-03-12 19:28:10','2001-03-01 08:08:08'),(12,6,13,'2018-07-08 08:02:43','1996-10-10 02:25:29'),(13,7,17,'2011-08-06 21:10:11','1982-03-14 08:43:10'),(14,1,23,'2005-01-04 21:10:50','1983-09-27 00:46:48'),(15,6,19,'2001-04-04 22:46:11','1988-05-23 20:20:46'),(16,1,34,'1990-08-15 07:54:06','2011-08-07 05:45:24'),(17,5,13,'1974-07-31 20:14:49','2010-10-21 10:55:52'),(18,2,5,'1987-12-09 11:49:26','1981-11-16 01:23:22'),(19,6,16,'1983-12-18 02:56:16','2002-12-10 16:43:05'),(20,1,33,'1999-11-02 06:54:21','2002-04-27 11:14:07'),(21,1,11,'1979-07-18 01:13:28','1988-04-20 17:32:26'),(22,1,5,'1990-04-20 15:46:38','2003-03-02 11:36:20'),(23,3,18,'1987-03-17 13:33:58','1973-08-16 11:21:08'),(24,5,3,'1996-05-17 13:47:26','2002-09-07 03:37:19'),(25,4,2,'2014-05-16 08:56:26','1990-05-19 20:05:55'),(26,2,18,'1988-10-05 06:28:22','2014-01-19 13:25:37'),(27,6,40,'1990-11-08 22:33:03','1972-12-31 01:24:52'),(28,6,28,'2008-08-25 20:09:14','2008-08-13 16:56:52'),(29,3,36,'1997-10-03 23:33:28','1977-04-25 14:02:05'),(30,2,10,'1994-07-28 00:46:04','1995-07-03 09:32:28'),(31,3,15,'1991-01-22 15:04:26','1973-07-20 13:48:43'),(32,1,39,'2019-11-14 22:13:24','2003-07-08 10:00:57'),(33,5,13,'2013-07-01 16:56:40','1984-10-04 11:24:50'),(34,1,18,'1982-05-09 10:30:26','1976-12-19 07:50:52'),(35,5,6,'2020-04-19 18:50:52','2013-08-18 20:46:36'),(36,2,33,'1995-05-13 00:56:44','1993-06-03 23:50:28'),(37,3,11,'2009-07-28 08:33:32','2018-05-15 16:07:25'),(38,7,31,'1979-10-01 21:50:28','2016-03-13 22:15:52'),(39,5,25,'1974-10-28 15:37:19','2016-09-20 12:33:08'),(40,6,6,'1971-06-22 21:17:33','2001-01-06 02:54:45');
/*!40000 ALTER TABLE `team_to_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '╨Ш╨┤╨╡╨╜╤В╨╕╤Д╨╕╨║╨░╤В╨╛╤А ╤Б╤В╤А╨╛╨║╨╕',
  `first_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Ш╨╝╤П ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П',
  `last_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨д╨░╨╝╨╕╨╗╨╕╤П ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П',
  `employee_id` int NOT NULL COMMENT 'ID ╨┐╨╛╨╗╤М╨╖╨╛╨▓╨░╤В╨╡╨╗╤П ╨▓ ╤Б╨╕╤Б╤В╨╡╨╝╨╡ ╤А╨░╨▒╨╛╤В╨╛╨┤╨░╤В╨╡╨╗╤П',
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨в╨╡╨╗╨╡╤Д╨╛╨╜',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '╨Я╨╛╤З╤В╨░',
  `office_id` int unsigned NOT NULL COMMENT '╨Ю╤Д╨╕╤Б ╤В╤А╤Г╨┤╨╛╤Г╤Б╤В╤А╨╛╨╣╤Б╤В╨▓╨░',
  `citizen_id` int unsigned NOT NULL COMMENT '╨У╤А╨░╨╢╨┤╨░╨╜╤Б╤В╨▓╨╛',
  `job_id` int unsigned NOT NULL COMMENT '╨Ф╨╛╨╗╨╢╨╜╨╛╤Б╤В╤М ╤Б╨╛╤В╤А╤Г╨┤╨╜╨╕╨║╨░',
  `job_in_ext` int unsigned NOT NULL COMMENT '╨в╨╕╨┐ ╨╖╨░╨╜╤П╤В╨╛╤Б╤В╨╕ ╤Б╨╛╤В╤А╤Г╨┤╨╜╨╕╨║╨░, ╨░╤Г╤В╤Б╨╛╤А╤Б, ╤И╤В╨░╤В',
  `permission_id` int unsigned NOT NULL COMMENT '╨Я╤А╨░╨▓╨░ ╨┤╨╛╤Б╤В╤Г╨┐╨░',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╤Б╨╛╨╖╨┤╨░╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '╨Т╤А╨╡╨╝╤П ╨╛╨▒╨╜╨╛╨▓╨╗╨╡╨╜╨╕╤П ╤Б╤В╤А╨╛╨║╨╕',
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `email` (`email`),
  KEY `users_office_id_fr` (`office_id`),
  KEY `users_citizen_id_fk` (`citizen_id`),
  KEY `users_job_id_fk` (`job_id`),
  KEY `users_job_ext_id_fk` (`job_in_ext`),
  KEY `users_permission_id_fk` (`permission_id`),
  CONSTRAINT `users_citizen_id_fk` FOREIGN KEY (`citizen_id`) REFERENCES `citizenship_types` (`id`),
  CONSTRAINT `users_job_ext_id_fk` FOREIGN KEY (`job_in_ext`) REFERENCES `job_types` (`id`),
  CONSTRAINT `users_job_id_fk` FOREIGN KEY (`job_id`) REFERENCES `Job_position_types` (`id`),
  CONSTRAINT `users_office_id_fr` FOREIGN KEY (`office_id`) REFERENCES `office_options` (`id`),
  CONSTRAINT `users_permission_id_fk` FOREIGN KEY (`permission_id`) REFERENCES `permission_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='╨Я╤А╨╛╤Д╨╕╨╗╨╕ ╨▓ ╤Б╨╕╤Б╤В╨╡╨╝╨╡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Mckenna','Batz',1484,'04421032088','wilmer.howell@example.com',15,6,2,6,4,'1997-05-21 01:22:49','1996-01-02 12:19:09'),(2,'Dino','Koss',1432,'+26(4)1247661533','marc27@example.net',16,5,5,2,5,'1984-05-28 12:43:47','2017-11-15 15:44:20'),(3,'Newell','Collier',1146,'1-352-226-5520x20118','fbayer@example.com',14,7,4,7,4,'1999-05-12 13:43:59','1978-10-03 22:06:27'),(4,'Arvid','Schuster',1165,'(757)678-5382','qgerlach@example.org',10,19,2,1,1,'2019-02-26 10:06:14','1998-09-16 18:06:34'),(5,'Minerva','D\'Amore',1109,'(800)447-8627','kyra19@example.net',3,12,2,5,1,'2000-11-19 01:00:16','1985-11-13 09:28:11'),(6,'Ethelyn','Bode',1021,'220.492.0692','garrett34@example.org',12,7,1,5,3,'2009-10-10 03:51:26','1993-08-20 19:11:34'),(7,'Mittie','Labadie',1408,'797-702-3464x00331','makenzie.emmerich@example.net',5,9,4,4,2,'2006-10-27 03:03:38','1982-08-12 15:11:04'),(8,'Krystel','Dietrich',1392,'1-955-967-8910x55940','joaquin.shanahan@example.net',9,5,3,3,2,'2015-06-19 18:38:38','2010-06-29 01:47:00'),(9,'Nelda','Kuphal',1310,'160-564-3932','thompson.ethan@example.com',9,19,4,2,5,'1994-11-02 19:54:44','1992-09-22 09:35:45'),(10,'Kyler','Konopelski',1024,'356-645-3004x6521','sim.lakin@example.net',7,14,5,4,4,'1984-06-25 21:01:00','1996-03-25 09:06:14'),(11,'Daisha','Lebsack',1446,'746.657.2306','holly.king@example.org',17,14,2,2,2,'2000-07-11 06:35:10','2006-01-31 12:09:22'),(12,'Hildegard','Mueller',1185,'(617)873-8840','tremayne56@example.com',9,16,4,4,3,'2010-02-25 13:45:39','2015-05-24 06:34:30'),(13,'Geovanny','Spinka',1465,'438-216-5021x8111','marcelle93@example.org',3,16,5,7,2,'1973-12-03 02:20:15','1976-07-03 18:36:55'),(14,'Adrien','Dickens',1137,'412.365.6262x625','pborer@example.com',2,7,3,5,4,'1995-10-28 06:24:21','1988-05-12 13:51:20'),(15,'Gustave','Wyman',1402,'00309249222','darius.hahn@example.net',17,1,3,4,2,'1974-09-02 13:50:58','1973-04-15 03:58:55'),(16,'Ulices','Zieme',1156,'(263)427-1721x401','earlene.schuppe@example.com',10,16,5,2,2,'1979-11-12 21:49:44','2014-04-03 21:42:10'),(17,'Gerda','Runolfsdottir',1052,'236.821.9625x647','thompson.modesta@example.com',14,3,1,1,2,'1978-10-03 11:03:21','1998-07-11 00:11:35'),(18,'Emery','Feest',1217,'1-977-427-6146','dubuque.oma@example.org',8,9,1,1,1,'2008-08-03 13:05:13','1989-06-30 14:07:45'),(19,'Uriel','Vandervort',1274,'616-972-2695','zkirlin@example.com',10,4,4,3,1,'2013-03-23 15:58:07','1990-08-11 01:08:32'),(20,'Salvatore','Schowalter',1293,'+32(7)0391482662','tad.farrell@example.org',1,10,3,4,1,'2000-03-11 09:40:57','1985-08-25 18:29:08'),(21,'Bridie','Medhurst',1067,'(475)838-7550x038','icollins@example.net',1,7,1,4,4,'1998-10-06 00:20:54','2000-10-06 11:59:15'),(22,'Korbin','Stiedemann',1371,'(656)848-6000x666','lester83@example.com',6,1,3,2,2,'1998-06-27 04:20:17','1978-09-04 02:11:14'),(23,'Chadd','Kilback',1166,'(959)207-4483','trice@example.com',18,17,3,7,5,'2020-07-04 11:23:58','2020-04-15 04:51:53'),(24,'Stanford','Murray',1383,'503.191.9019x3578','grant59@example.com',14,5,2,6,2,'2005-02-01 18:16:32','2020-07-11 20:59:03'),(25,'Devyn','Kub',1388,'021-991-8694','koss.nova@example.org',6,5,3,1,4,'2004-06-18 06:01:33','1993-08-05 22:35:18'),(26,'Vida','Labadie',1094,'514.808.0102x7426','vmurazik@example.net',11,3,1,7,4,'1995-06-11 12:48:36','2014-08-31 15:53:05'),(27,'Alisha','Leannon',1340,'966.337.7638','dorcas.o\'keefe@example.net',3,19,5,2,3,'1970-04-12 16:23:35','1976-06-29 13:04:15'),(28,'Jody','Wehner',1263,'(467)774-7588x24630','abdul.crist@example.com',15,9,3,2,3,'1989-10-26 23:56:32','1986-12-02 16:22:36'),(29,'Allison','Maggio',1379,'(309)053-9149','glabadie@example.com',16,3,3,2,1,'2003-10-18 15:13:13','1971-03-28 16:23:25'),(30,'Deshaun','Hudson',1030,'+12(3)5497354026','fannie50@example.net',6,19,2,4,4,'2004-07-27 05:42:35','2015-06-03 18:21:47'),(31,'Tavares','Turner',1159,'(605)324-3914','leonora.eichmann@example.com',11,17,5,7,5,'2010-02-28 11:06:43','1984-10-07 20:20:18'),(32,'Mariano','Harber',1406,'628.903.2466','elisa.kling@example.org',10,10,1,4,3,'1989-05-03 02:56:09','2013-10-03 15:45:18'),(33,'Taryn','Jones',1245,'1-291-643-2918','mkuphal@example.com',14,14,2,5,5,'1977-10-12 21:04:02','1981-03-12 11:42:49'),(34,'Hellen','Orn',1338,'(748)772-5129','bauch.norris@example.net',17,6,2,3,3,'2009-12-27 02:05:31','2010-06-06 10:35:18'),(35,'Leonie','Corkery',1206,'(768)650-4263','mayert.alvera@example.org',18,3,4,3,2,'1978-03-14 10:37:31','1977-11-12 15:18:43'),(36,'Davon','Abernathy',1184,'(294)780-1617x8888','waldo69@example.com',14,12,2,7,1,'2013-06-13 14:39:58','2005-05-21 08:44:17'),(37,'Makayla','Rath',1036,'420-488-2816x88691','schulist.cory@example.net',19,9,5,6,2,'2011-11-18 00:12:07','1986-08-26 02:02:26'),(38,'Georgianna','Pagac',1216,'(687)919-0421','gerlach.howard@example.net',17,6,5,6,5,'2014-05-18 16:33:19','1970-05-28 12:22:22'),(39,'Lempi','Turcotte',1389,'564-519-8119','ywolf@example.com',6,10,3,5,1,'2003-08-08 01:28:25','2015-01-15 11:52:16'),(40,'Nannie','Weber',1190,'1-733-665-7251','fblick@example.org',7,10,2,5,4,'1989-02-08 20:28:36','2008-08-28 06:23:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`natkay`@`%`*/ /*!50003 TRIGGER `validate_user_access_on_insert` BEFORE UPDATE ON `users` FOR EACH ROW BEGIN
  IF NEW.id IN (SELECT id FROM customer_users) 
  	AND NEW.permission_id != 1 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Permission should be either blank or quas, you are trying to add priviliges to customer';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping routines for database 'pdm_NI3'
--
/*!50003 DROP FUNCTION IF EXISTS `is_row_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`natkay`@`%` FUNCTION `is_row_exists`(target_id INT) RETURNS tinyint(1)
    READS SQL DATA
BEGIN
   RETURN EXISTS(SELECT 1 FROM parts WHERE id = target_id);
 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `citizen_us`
--

/*!50001 DROP TABLE IF EXISTS `citizen_us`*/;
/*!50001 DROP VIEW IF EXISTS `citizen_us`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`natkay`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `citizen_us` AS select `users`.`id` AS `id`,`users`.`first_name` AS `first_name`,`users`.`last_name` AS `last_name`,`users`.`employee_id` AS `employee_id`,`users`.`phone` AS `phone`,`users`.`email` AS `email`,`users`.`office_id` AS `office_id`,`users`.`citizen_id` AS `citizen_id`,`users`.`job_id` AS `job_id`,`users`.`job_in_ext` AS `job_in_ext`,`users`.`permission_id` AS `permission_id`,`users`.`created_at` AS `created_at`,`users`.`updated_at` AS `updated_at` from `users` where `users`.`id` in (select `citizenship_types`.`id` from `citizenship_types` where (`citizenship_types`.`name` = 'US')) order by `users`.`last_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_users`
--

/*!50001 DROP TABLE IF EXISTS `customer_users`*/;
/*!50001 DROP VIEW IF EXISTS `customer_users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`natkay`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_users` AS select `users`.`id` AS `id`,`users`.`first_name` AS `first_name`,`users`.`last_name` AS `last_name`,`users`.`employee_id` AS `employee_id`,`users`.`phone` AS `phone`,`users`.`email` AS `email`,`users`.`office_id` AS `office_id`,`users`.`citizen_id` AS `citizen_id`,`users`.`job_id` AS `job_id`,`users`.`job_in_ext` AS `job_in_ext`,`users`.`permission_id` AS `permission_id`,`users`.`created_at` AS `created_at`,`users`.`updated_at` AS `updated_at` from `users` where `users`.`id` in (select `customer_comp_id`.`contact_name` from `customer_comp_id`) order by `users`.`last_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-09 16:41:40
