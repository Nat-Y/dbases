-- ������� ����� ��� ��
use pdm_NI3;

-- ������� �������������
ALTER TABLE users
  ADD CONSTRAINT users_office_id_fr 
    FOREIGN KEY (office_id) REFERENCES office_options(id),
  ADD CONSTRAINT users_citizen_id_fk 
    FOREIGN KEY (citizen_id) REFERENCES citizenship_types(id),
  ADD CONSTRAINT users_job_id_fk 
 	FOREIGN KEY (job_id) REFERENCES Job_position_types(id),
  ADD CONSTRAINT users_job_ext_id_fk 
    FOREIGN KEY (job_in_ext) REFERENCES job_types(id),
  ADD CONSTRAINT users_permission_id_fk 
    FOREIGN KEY (permission_id) REFERENCES permission_id(id);
    
   -- ������� ������
ALTER TABLE file
  ADD CONSTRAINT file_user_creator_id_fr 
    FOREIGN KEY (user_creator_id) REFERENCES users(id),
  ADD CONSTRAINT file_user_curr_own_id_fr 
    FOREIGN KEY (user_curr_own_id) REFERENCES users(id),
  ADD CONSTRAINT file_user_current_upd_id_fk 
    FOREIGN KEY (user_current_upd_id) REFERENCES users(id),
  ADD CONSTRAINT file_file_type_id_fk 
 	FOREIGN KEY (file_type_id) REFERENCES file_types(id),
  ADD CONSTRAINT file_lifecycle_id_fk 
    FOREIGN KEY (lifecycle_id) REFERENCES lifecycle_general(id),
  ADD CONSTRAINT file_is_released_fk 
    FOREIGN KEY (is_released) REFERENCES is_released(id),
  ADD CONSTRAINT file_permission_id_fk 
    FOREIGN KEY (permission_id) REFERENCES permission_id(id),
  ADD CONSTRAINT file_team_id_fk 
    FOREIGN KEY (team_id) REFERENCES team_id(id);
     
    -- ������� ����������
ALTER TABLE documents 
  ADD CONSTRAINT documents_user_creator_id_fr 
    FOREIGN KEY (user_creator_id) REFERENCES users(id),
  ADD CONSTRAINT documents_user_curr_own_id_fr 
    FOREIGN KEY (user_curr_own_id) REFERENCES users(id),
  ADD CONSTRAINT documents_user_current_upd_id_fk 
    FOREIGN KEY (user_current_upd_id) REFERENCES users(id),
  ADD CONSTRAINT documents_doc_type_id_fk 
 	FOREIGN KEY (type_id) REFERENCES doc_types(id),
  ADD CONSTRAINT documents_lifecycle_id_fk 
    FOREIGN KEY (lifecycle_id) REFERENCES lifecycle_general(id),
  ADD CONSTRAINT documents_is_released_fk 
    FOREIGN KEY (is_released) REFERENCES is_released(id),
  ADD CONSTRAINT documents_permission_id_fk 
    FOREIGN KEY (permission_id) REFERENCES permission_id(id),
  ADD CONSTRAINT documents_team_id_fk 
    FOREIGN KEY (team_id) REFERENCES team_id(id);  
   
 
       -- ������� �������
ALTER TABLE parts 
  ADD CONSTRAINT parts_user_creator_id_fr 
    FOREIGN KEY (user_creator_id) REFERENCES users(id),
  ADD CONSTRAINT parts_user_curr_own_id_fr 
    FOREIGN KEY (user_curr_own_id) REFERENCES users(id),
  ADD CONSTRAINT parts_user_current_upd_id_fk 
    FOREIGN KEY (user_current_upd_id) REFERENCES users(id),
  ADD CONSTRAINT parts_file_type_id_fk 
 	FOREIGN KEY (type_id) REFERENCES file_types(id),
  ADD CONSTRAINT parts_is_purchased_fk 
 	FOREIGN KEY (is_purchased) REFERENCES is_purchased(id),
  ADD CONSTRAINT parts_lifecycle_id_fk 
    FOREIGN KEY (lifecycle_id) REFERENCES lifecycle_general(id),
  ADD CONSTRAINT parts_is_released_fk 
    FOREIGN KEY (is_released) REFERENCES is_released(id),
  ADD CONSTRAINT parts_permission_id_fk 
    FOREIGN KEY (permission_id) REFERENCES permission_id(id),
  ADD CONSTRAINT parts_team_id_fk 
    FOREIGN KEY (team_id) REFERENCES team_id(id);  
  
   ALTER TABLE parts 
   ADD CONSTRAINT parts_part_type_id_fk 
 	FOREIGN KEY (type_id) REFERENCES part_types(id);
 
          -- ������� ����� ���������� � ������
ALTER TABLE file_to_doc 
  ADD CONSTRAINT parts_file_id_fr 
    FOREIGN KEY (file_id) REFERENCES file(id),
  ADD CONSTRAINT parts_doc_id_fr 
    FOREIGN KEY (doc_id) REFERENCES documents(id);
   
          -- ������� ����� ���������� � �������
ALTER TABLE doc_to_parts 
  ADD CONSTRAINT doc_to_parts_part_id_fr 
    FOREIGN KEY (part_id) REFERENCES parts(id),
  ADD CONSTRAINT doc_to_parts_doc_id_fr 
    FOREIGN KEY (doc_id) REFERENCES documents(id);
   
             -- ������� ����� ������� part to part
ALTER TABLE part_to_part 
  ADD CONSTRAINT part_to_part_part_id_parent_fr 
    FOREIGN KEY (part_parent_id) REFERENCES parts(id),
  ADD CONSTRAINT part_to_part_part_id_child_fr 
    FOREIGN KEY (part_child_id) REFERENCES parts(id);
   
-- ������� ����������
ALTER TABLE customer_comp_id 
  ADD CONSTRAINT customer_contact_name_fr 
    FOREIGN KEY (contact_name) REFERENCES users(id),
  ADD CONSTRAINT customer_inter_contact_name_fk 
    FOREIGN KEY (inter_contact_name) REFERENCES users(id),
  ADD CONSTRAINT customer_country_fk 
 	FOREIGN KEY (country) REFERENCES country(id);   
 
 -- ������� ������������ ���������� �������
ALTER TABLE part_to_customer 
  ADD CONSTRAINT part_to_customer_customer_id_fr 
    FOREIGN KEY (customer_id) REFERENCES customer_comp_id(id),
  ADD CONSTRAINT part_to_customer_part_id_fk 
    FOREIGN KEY (part_id) REFERENCES parts(id);   
 
 -- ������� ������ ����� � ������
ALTER TABLE team_to_user 
  ADD CONSTRAINT team_to_user_group_id_fr 
    FOREIGN KEY (group_id) REFERENCES team_id(id),
  ADD CONSTRAINT team_to_user_person_id_fk 
    FOREIGN KEY (person_id) REFERENCES users(id); 
   
   
   